import {paintGeneratedFace} from '../../lib/craft3d/generated-face-paint.js';
import {addPaintedHairShell} from '../../lib/craft3d/painted-hair-shell.js';
import {addAtlasHairVolume} from '../../lib/craft3d/atlas-hair-volume.js';
import {addMorphPaintedHair} from '../../lib/craft3d/morph-painted-hair.js';

export function aoiGeneratedFace(base){
  return {...base,textureSize:2048,skin:'#ffddbf',paintFace:paintGeneratedFace,
    irisArt:new URL('./textures/aoi-painted-face-v1.png',import.meta.url).href,
    paint:{originX:642,originY:658,anchorY:1.473,pixelsPerMetre:3300,
      eyes:[[500,656,458,600,85,111],[785,655,743,599,85,111]],mouth:[641,852]},
    cheekFullness:.045,neckZ:.012,neckTopZ:.008,neckRadius:.034,earZ:-.043,
    neckProfile:[[1.300,.034,.041,-.030],[1.335,.032,.041,-.028],[1.375,.032,.036,-.036],[1.415,.037,.032,-.050],[1.452,.046,.024,-.063]],
    drawnEar:true,
    faceRoundness:1.45,noseDepth:0,
    eyeSurface:{slope:.36,recess:.014,width:.030,height:.027},
    earPaint:[[290,620,115,182],[872,620,114,182]],
    profileContour:[[1.376,.079],[1.380,.086],[1.391,.091],[1.403,.094],[1.413,.098],[1.419,.100],[1.426,.099],[1.431,.103],[1.436,.111],[1.441,.117],[1.446,.116],[1.453,.108],[1.462,.099],[1.473,.097],[1.483,.100],[1.510,.104],[1.537,.100],[1.574,.065],[1.605,.012],[1.612,-.028]],
    jawContour:[[1.376,.076],[1.380,.056],[1.389,.011],[1.406,-.033],[1.418,-.052],[1.438,-.073],[1.464,-.088],[1.505,-.105],[1.537,-.110],[1.574,-.099],[1.605,-.060],[1.612,-.029]],
    profiles:[[1.376,.001,.087,.080],[1.382,.019,.092,.062],[1.394,.042,.096,.016],[1.406,.056,.098,-.016],[1.418,.067,.100,-.042],[1.438,.079,.099,-.067],[1.464,.091,.099,-.088],[1.505,.093,.103,-.105],[1.537,.087,.099,-.110],[1.574,.065,.065,-.099],[1.605,.018,.012,-.060],[1.612,.001,-.028,-.029]]};
}
export function addAoiGeneratedHair(actor,{profileExperiment=false,surfacePaint=false,importedGeometry=null,atlasVolume=false,morphPaint=false,geometryWrap=false}={}){
  if(morphPaint)return addMorphPaintedHair(actor,{frontUrl:new URL('./textures/aoi-painted-hair-v1.png',import.meta.url).href,atlasUrl:new URL('./textures/aoi-profile-hair-atlas-v1.png',import.meta.url).href});
  if(atlasVolume)return addAtlasHairVolume(actor,{frontUrl:new URL('./textures/aoi-painted-hair-v1.png',import.meta.url).href,atlasUrl:new URL('./textures/aoi-profile-hair-atlas-v1.png',import.meta.url).href});
  return addPaintedHairShell(actor,{
    url:new URL('./textures/aoi-painted-hair-v1.png',import.meta.url).href,
    backUrl:new URL('./textures/aoi-painted-back-v1.png',import.meta.url).href,
    originX:615,originY:654,anchorY:1.473,pixelsPerMetre:3186,
    projectionRadii:[.166,.163,.142],
    importedGeometry,
    geometryWrap,
    templeWrap:.065,
    ...(profileExperiment||surfacePaint?{
      tailDepth:-.095,tailOffset:-.110,tailRoundness:1.6,
      surfacePaint,
      sidePaint:{url:new URL('./textures/aoi-profile-hair-atlas-v1.png',import.meta.url).href,scale:1030,right:[690,590],left:[201,182],anchorY:1.473,sourceSize:[1310,1200]},
      cap:{center:[0,1.520,-.012],radii:[.106,.124,.108],hem:[[-180,1.431],[-145,1.436],[-110,1.450],[-80,1.476],[-45,1.550],[0,1.575],[45,1.550],[80,1.476],[110,1.450],[145,1.436],[180,1.431]]}
    }:{cap:{center:[0,1.514,-.027],radii:[.112,.140,.121],hem:[[-180,1.400],[-145,1.407],[-110,1.430],[-80,1.470],[-45,1.550],[0,1.575],[45,1.550],[80,1.470],[110,1.430],[145,1.407],[180,1.400]]}}),
    ...(geometryWrap?{tailDepth:-.060,tailOffset:-.075,sidePaint:{url:new URL('./textures/aoi-profile-hair-atlas-v1.png',import.meta.url).href,scale:1030,right:[690,590],left:[201,182],anchorY:1.473,sourceSize:[1310,1200]},cap:{center:[0,1.523,-.016],radii:[.106,.128,.113],hem:[[-180,1.416],[-145,1.420],[-110,1.443],[-80,1.476],[-45,1.550],[0,1.575],[45,1.550],[80,1.476],[110,1.443],[145,1.420],[180,1.416]]}}:{}),
    capCrop:[295,140,240,330]
  });
}
