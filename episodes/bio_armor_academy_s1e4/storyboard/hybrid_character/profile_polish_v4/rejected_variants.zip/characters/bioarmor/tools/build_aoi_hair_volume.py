"""Build fixed 3-D hair volume from authored masses constrained by painted masks.

The images are read only. This produces geometry, not a retouched raster image.
Python dependencies: numpy, scipy, scikit-image, Pillow.
"""
from pathlib import Path
import hashlib
import json
import struct
import numpy as np
from PIL import Image
from scipy.ndimage import map_coordinates, gaussian_filter, label, distance_transform_edt
from skimage.measure import marching_cubes

ROOT = Path(__file__).resolve().parents[1]
FRONT = ROOT / 'textures/aoi-painted-hair-v1.png'
SIDE = ROOT / 'textures/aoi-profile-hair-atlas-v1.png'
OUT = ROOT / 'models/aoi-painted-hair-volume-v1.bin'
STEP = .0018

def alpha(path):
    return np.asarray(Image.open(path).convert('RGBA'), dtype=np.float32)[:, :, 3] / 255

def sample(a, px, py):
    px, py = np.broadcast_arrays(px, py)
    return map_coordinates(a, [py.ravel(), px.ravel()], order=1, mode='constant', cval=0).reshape(px.shape)

def smooth(a, low, high):
    t = np.clip((a-low)/(high-low), 0, 1)
    return t*t*(3-2*t)

x = np.arange(-.18, .25+STEP, STEP, dtype=np.float32)
y = np.arange(1.27, 1.68+STEP, STEP, dtype=np.float32)
z = np.arange(-.26, .16+STEP, STEP, dtype=np.float32)
X, Y, Z = x[:, None, None], y[None, :, None], z[None, None, :]
front = sample(alpha(FRONT), 615+X*3186, 654+(1.473-Y)*3186)
side = sample(alpha(SIDE), 690+Z*1030, 590+(1.473-Y)*1030)
side *= ((690+Z*1030)>442)&((690+Z*1030)<868)&((590+(1.473-Y)*1030)>402)&((590+(1.473-Y)*1030)<792)

boundary=np.interp(Y,[1.27,1.36,1.41,1.46,1.52,1.58,1.62,1.68],[-.075,-.075,-.08,-.120,-.142,-.140,-.112,-.08])
mask=gaussian_filter(side[0],.65)>.43
def signed(mask):
    return (distance_transform_edt(mask)-distance_transform_edt(~mask))*STEP
cap_sdf=signed(mask & (Z[0]>boundary[0]-.008))
tail_sdf=signed(mask & (Z[0]<boundary[0]+.008))
# Rounded signed-distance sections meet at the silhouette. Unlike alpha-mask
# extrusion, small gaps do not become rectangular corridors through the scalp.
cap=(cap_sdf[None,:,:] - .040*(X/.105)**2)>0
tail=(tail_sdf[None,:,:] - .040*((X-.155)/.049)**2)>0
density=cap|tail
# Keep the accepted front sheet as the foremost surface. Its painted wisps
# remain a thin detail layer over this continuous opaque volume.
scalp = -.012+.142*(np.sqrt(np.maximum(.002,1-(X/.166)**2-((Y-1.520)/.163)**2))-.18*np.sqrt(np.maximum(0,(X/.166)**2+((Y-1.520)/.163)**2-1)))
fw = (1-smooth(Y,1.495,1.575))*(1-smooth(abs(X),.10,.155))
temple = .065*smooth(abs(X),.030,.095)*(1-smooth(Y,1.49,1.57))*(1-smooth(X,.10,.13))
front_depth = scalp*(1-fw)+np.maximum(scalp,.112-.26*abs(X))*fw+.004-temple
tw = smooth(X,.105,.175)
front_depth = front_depth*(1-tw)+(-.095+.008*np.sin(np.clip((1.66-Y)/.36,0,1)*4))*tw
density &= (Z < front_depth-.002) | ((X>.100)&(Z<-.100))
field = gaussian_filter(density.astype(np.float32), 1.2)
field[[0,-1],:,:]=0;field[:,[0,-1],:]=0;field[:,:,[0,-1]]=0
components, count = label(field>.42)
sizes = np.bincount(components.ravel());sizes[0]=0
field *= sizes[components]>30
vertices, faces, _, _ = marching_cubes(field, .42, spacing=(STEP,STEP,STEP), allow_degenerate=False)
vertices += np.array([x[0],y[0],z[0]])
# skimage's ascent/descent convention differs from the rendering winding.
faces = faces[:, [0,2,1]]
OUT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_bytes(struct.pack('<IIII',0x48414952,1,len(vertices),faces.size)+vertices.astype('<f4').tobytes()+faces.astype('<u4').tobytes())
edges = np.sort(np.concatenate([faces[:,[0,1]],faces[:,[1,2]],faces[:,[2,0]]]),axis=1)
_, multiplicity = np.unique(edges,axis=0,return_counts=True)
report={'step':STEP,'vertices':len(vertices),'triangles':len(faces),'boundaryEdges':int(np.sum(multiplicity==1)),'nonManifoldEdges':int(np.sum(multiplicity>2)),
        'inputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [FRONT,SIDE]},'meshSha256':hashlib.sha256(OUT.read_bytes()).hexdigest()}
OUT.with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report))
