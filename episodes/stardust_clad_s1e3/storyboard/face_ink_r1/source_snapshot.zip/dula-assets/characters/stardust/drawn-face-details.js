const TAU=Math.PI*2;
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));

// Opt-in paint on the existing curved face UV. The live gaze, eyelid clip and
// mouth paint remain the source of timing; this adds no camera-facing planes.
export function installDrawnFaceDetails(actor){
 const previous=actor.palacePortrait.afterPaint;
 const settings={enabled:true};
 actor.palacePortrait.afterPaint=(ctx,state)=>{
  previous?.(ctx,state);
  if(!settings.enabled)return;
  const g=ctx,act=state.acting??{};
  const focus=clamp(act.focus??0),fear=clamp(act.fear??0);
  const open=1-clamp(act.blink??state.blink??0);
  const gx=clamp(act.gazeX??state.gaze.x,-1,1),gy=clamp(act.gazeY??state.gaze.y,-1,1);
  g.save();g.setTransform(2,0,0,2,0,0);
  if(open>.045&&state.emotion!=='laugh')for(const side of [-1,1]){
   const h=35*(1+.15*fear-.16*focus),cx=256+side*84;
   g.save();g.translate(cx,248);g.scale(side*1.03,1);
   // Inset clipping retains the existing eyelid ink.
   g.beginPath();g.moveTo(-45,2);g.lineTo(-35,-h*.72*open+2);
   g.quadraticCurveTo(-6,-h*open+2,27,-h*.87*open+2);
   g.lineTo(48,-h*.38*open+1);g.lineTo(38,14*.70*open-1);
   g.quadraticCurveTo(8,14*open-1,-26,14*.72*open-1);g.closePath();g.clip();
   const ix=-2+gx*side*16,iy=-6+gy*10;
   const iris=g.createLinearGradient(0,iy-37,0,iy+37);
   iris.addColorStop(0,'#162936');iris.addColorStop(.42,'#2e6068');
   iris.addColorStop(.72,'#63a3a7');iris.addColorStop(1,'#bed5b7');
   g.fillStyle=iris;g.beginPath();g.ellipse(ix,iy,21,37,0,0,TAU);g.fill();
   g.strokeStyle='#233b44';g.lineWidth=2;g.stroke();
   // Broken lower iris reflections, kept inside the painted iris.
   g.save();g.beginPath();g.ellipse(ix,iy,19.5,35,0,0,TAU);g.clip();
   g.strokeStyle='rgba(203,224,187,.7)';g.lineWidth=2.1;g.lineCap='round';
   for(const [angle,len]of [[.40,5],[.72,6],[1.07,7],[1.53,5],[1.92,6],[2.36,5],[2.73,4]]){
    const x=Math.cos(angle),y=Math.sin(angle);
    g.beginPath();g.moveTo(ix+x*16,iy+y*27);
    g.lineTo(ix+x*(16-len*.45),iy+y*(27-len));g.stroke();
   }
   g.restore();
   g.fillStyle='#152630';g.beginPath();g.ellipse(ix,iy-2,9.5*(act.pupil??1),16,0,0,TAU);g.fill();
   g.fillStyle='rgba(14,29,40,.22)';g.beginPath();g.ellipse(ix,iy-25,22,12,0,0,TAU);g.fill();
   // One broad key reflection and a smaller low reflection follow the iris.
   g.fillStyle='#fffef1';g.beginPath();g.ellipse(ix-7*side,iy-14,6.5,7,-side*.35,0,TAU);g.fill();
   g.beginPath();g.ellipse(ix+9*side,iy+11,3,2.2,0,0,TAU);g.fill();
   g.restore();
  }
  // Short, tapered warm lines describe planes. They are weaker than lashes
  // and avoid a full cheek contour, fixed blush hatch or skin-color blocks.
  const stroke=(points,width,color)=>{
   g.strokeStyle=color;g.lineWidth=width;g.lineCap='round';
   g.beginPath();g.moveTo(...points[0]);g.quadraticCurveTo(...points[1],...points[2]);g.stroke();
  };
  for(const side of [-1,1]){
   const x=256+side*84;
   stroke([[x+side*27,274],[x+side*35,273],[x+side*41,269]],1.35,'#a7827f');
   stroke([[x+side*31,281],[x+side*35,282],[x+side*38,281]],.85,'#baa09a');
  }
  g.fillStyle='rgba(161,108,96,.20)';g.beginPath();g.moveTo(260,303);
  g.quadraticCurveTo(262,312,267,316);g.lineTo(260,321);g.lineTo(258,317);g.closePath();g.fill();
  stroke([[260,301],[260,309],[264,315]],1.5,'#96736d');
  stroke([[253,323],[256,325],[259,323]],1.2,'#94716d');
  stroke([[247,370],[255,372],[264,369]],1.0,'#bb9890');
  g.restore();
 };
 const api={
  setEnabled(on){settings.enabled=on;},
  get enabled(){return settings.enabled;}
 };
 actor.drawnFaceDetails=api;
 return api;
}
