import * as THREE from 'three';

// Authored sheet silhouettes, rather than elliptical tubes. This is an opt-in
// study for the wind cast; it does not replace earlier episodes' accepted hair.
const V=p=>new THREE.Vector3(...p), lerp=THREE.MathUtils.lerp;
const center=V([0,.082,-.018]), radii=V([.143,.200,.157]);
const smooth=THREE.MathUtils.smoothstep;

function material(color){
 const m=new THREE.MeshBasicMaterial({color,side:THREE.DoubleSide});
 m.onBeforeCompile=s=>{
  s.vertexShader='varying vec3 hairForm; varying vec3 hairLocal;\n'+s.vertexShader;
  s.vertexShader=s.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
   hairLocal=position;
   // Shade the head-sized mass. Do not put a bright cylinder on every lock.
   hairForm=normalize(mat3(modelMatrix)*normalize((position-vec3(0.,.082,-.018))/vec3(.143,.200,.157)));`);
  s.fragmentShader='varying vec3 hairForm; varying vec3 hairLocal;\n'+s.fragmentShader;
  s.fragmentShader=s.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
   float lit=dot(normalize(hairForm),normalize(vec3(-.45,.65,.7)));
   float shadow=1.-smoothstep(.18,.22,lit);
   diffuseColor.rgb*=mix(vec3(1.),vec3(.61,.64,.73),shadow);
   // One quiet painted band shared across the mass, not per-strand specular.
   float band=smoothstep(.176,.181,hairLocal.y)*(1.-smoothstep(.193,.198,hairLocal.y));
   diffuseColor.rgb*=1.+band*.16*(1.-shadow);`);
 };
 m.customProgramCacheKey=()=> 'layered-hair-mass-v1';
 return m;
}

function sheet(root,points,widths,name,mat,{normal=[0,0,1],ink=true,depth=.0022,lag=1}={}){
 const curve=new THREE.CatmullRomCurve3(points.map(V)),n=36,m=10;
 const vertices=[],indices=[],frames=[],edges=[[],[]];
 const layer=.0015+root.children.length*.00008;
 const wrap=(q,u)=>{
  // Roots and middle belong to the cranial surface. Width on a free-space
  // curve otherwise creates upright fins when its tangent lies across the brow.
  const ellipsoid=radii.clone().addScalar(layer),d=q.clone().sub(center).divide(ellipsoid);
  const onHead=d.normalize().multiply(ellipsoid).add(center);
  return q.lerp(onHead,1-smooth(u,.57,.89));
 };
 let side=V(normal).cross(curve.getTangent(0)).normalize();
 const width=u=>{
  const k=u*(widths.length-1),i=Math.min(widths.length-2,Math.floor(k));
  return lerp(widths[i],widths[i+1],k-i);
 };
 let previous=curve.getTangent(0);
 for(let i=0;i<=n;i++){
  const u=i/n,t=curve.getTangent(u),p=curve.getPoint(u);
  if(i)side.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(previous,t));
  const normal=t.clone().cross(side).normalize();previous=t;
  frames.push({p,side:side.clone(),normal});
  for(let j=0;j<=m;j++){
   const v=j/m*2-1;
   // A shallow, non-cylindrical sheet. The narrow tip is part of the silhouette.
   const q=wrap(p.clone().addScaledVector(side,v*width(u)).addScaledVector(normal,depth*(1-v*v)*Math.sin(Math.PI*u)),u);
   vertices.push(...q.toArray());
   if(j===0)edges[0].push(q.clone());
   if(j===m)edges[1].push(q.clone());
   if(i<n&&j<m){const k=i*(m+1)+j;indices.push(k,k+1,k+m+1,k+1,k+m+2,k+m+1);}
  }
 }
 const geometry=new THREE.BufferGeometry();
 geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
 geometry.setIndex(indices);geometry.computeVertexNormals();
 const mesh=new THREE.Mesh(geometry,mat);mesh.name=name;root.add(mesh);
 // Only selected overlapping edges get a tapered ink strip; roots merge.
 const lineGeometries=[];
 if(ink)for(const sign of [-1,1]){
  const pos=[],ix=[];
  for(let i=0;i<=n;i++){
   const u=i/n,{side,normal}=frames[i],edge=edges[sign<0?0:1][i];
   const thick=.00065*Math.sin(Math.PI*smooth(u,.10,1))*(sign<0?1:.70);
   for(const off of [0,thick]){
    const outward=edge.clone().sub(center).normalize().lerp(normal,smooth(u,.57,.89));
    const q=edge.clone().addScaledVector(side,-sign*off).addScaledVector(outward,.0010);
    pos.push(...q.toArray());
   }
   if(i<n){const k=i*2;ix.push(k,k+1,k+2,k+1,k+3,k+2);}
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));g.setIndex(ix);
  const line=new THREE.Mesh(g,new THREE.MeshBasicMaterial({color:'#162630',side:THREE.DoubleSide}));
  line.name=name+'-edge';root.add(line);lineGeometries.push(g);
 }
 return {name,lag,geometries:[geometry,...lineGeometries].map(g=>({g,rest:g.attributes.position.array.slice()}))};
}

export function installLayeredHair(actor,{hero=true}={}){
 const old=actor.softPortrait.hair,root=new THREE.Group();root.name='layered-hair-study';
 actor.headGroup.add(root);
 const mat=material(hero?'#354d59':'#514653'),parts=[];
 const sideMat=material(hero?'#2c414e':'#453b4d');
 const lightMat=material(hero?'#3e5763':'#5b4d60');
 const cp=[],ci=[],rows=28,cols=72;
 for(let i=0;i<=rows;i++)for(let j=0;j<=cols;j++){
  const a=j/cols*Math.PI*2,b=Math.acos(Math.cos(a));
  const keys=[[0,.94],[1.0,1.14],[1.56,1.56],[2.18,2.08],[Math.PI,2.30]];
  let end=2.30;
  for(let k=1;k<keys.length;k++)if(b<=keys[k][0]){
   end=lerp(keys[k-1][1],keys[k][1],smooth(b,keys[k-1][0],keys[k][0]));break;
  }
  const theta=i/rows*end;
  cp.push(.139*Math.sin(theta)*Math.sin(a),.082+.195*Math.cos(theta),-.018+.151*Math.sin(theta)*Math.cos(a));
  if(i<rows&&j<cols){const k=i*(cols+1)+j;ci.push(k,k+cols+1,k+1,k+1,k+cols+1,k+cols+2);}
 }
 const cg=new THREE.BufferGeometry();cg.setAttribute('position',new THREE.Float32BufferAttribute(cp,3));cg.setIndex(ci);cg.computeVertexNormals();
 const cap=new THREE.Mesh(cg,sideMat);root.add(cap);
 const add=(points,widths,name,options={})=>parts.push(sheet(root,points,widths,name,options.shade??mat,options));
 const scalp=(theta,a,pad=.004)=>{
  const r=radii.clone().addScalar(pad);
  return [r.x*Math.sin(theta)*Math.sin(a),center.y+r.y*Math.cos(theta),center.z+r.z*Math.sin(theta)*Math.cos(a)];
 };
 // Unequal sections: one broad mass broken into a few unequal trailing tips.
 const sections=[
  [.93,.025,1.69], [1.30,.034,1.78], [1.73,.034,2.13],
  [2.18,.041,2.40], [2.55,.044,2.46], [3.02,.038,2.57],
  [3.41,.043,2.49], [3.88,.036,2.43], [4.28,.039,2.20],
  [4.72,.029,1.82], [5.12,.029,1.79], [5.45,.019,1.80]
 ];
 for(const [i,[a,w,end]]of sections.entries()){
  const sweep=hero?-.16:.10;
  const tip=scalp(end+(hero?-.06:.18),a+sweep,.010);
  tip[0]+=Math.sin(a)*(hero?.018:.006);tip[1]-=hero?0:.018;
  const pts=[scalp(.30,a-.13,-.002),scalp(.85,a+sweep*.5,.004),scalp(end-.40,a+sweep,.006),tip];
  add(pts,[w*.35,w*.85,w*.70,w*.25,.0001],'back-section-'+i,{normal:[Math.sin(a),.25,Math.cos(a)],ink:i%3===0,lag:.8,shade:[1,4,8].includes(i)?sideMat:mat});
  // Split near the end, not a second independent root or a repeated cylinder.
  if([1,3,6,9].includes(i)){
   const p=scalp(end-.55,a+sweep,.007),q=scalp(end-.22,a+sweep+.12,.010),e=scalp(end-.04,a+sweep+.23,.015);
   e[0]+=Math.sin(a)*.018;e[1]+=.012;
   add([p,q,e],[w*.30,w*.37,.0001],'split-tip-'+i,{normal:[Math.sin(a),.1,Math.cos(a)],ink:false,lag:1.3});
  }
 }
 if(hero){
  // Short, asymmetrical sweep. Expose the far brow; vary lengths and tip gaps.
  add([[.035,.258,-.003],[.006,.251,.083],[-.054,.201,.150],[-.085,.087,.153]],[.004,.037,.035,.016,.0001],'hero-main-sweep',{shade:lightMat});
  add([[.025,.256,.004],[-.052,.247,.088],[-.108,.179,.124],[-.125,.096,.073]],[.004,.031,.028,.012,.0001],'hero-ear-fringe');
  add([[.040,.255,.018],[.033,.229,.136],[-.009,.162,.162],[-.034,.098,.161]],[.003,.021,.019,.008,.0001],'hero-fine-fringe',{lag:1.2});
  add([[.036,.256,.005],[-.010,.232,.105],[-.057,.158,.159],[-.061,.111,.160]],[.002,.011,.012,.006,.0001],'hero-fringe-split',{lag:1.25});
  add([[.042,.255,.008],[.057,.227,.129],[.054,.159,.159],[.030,.128,.160]],[.002,.018,.016,.006,.0001],'hero-part-inner',{shade:lightMat});
  add([[.038,.255,.008],[.092,.232,.099],[.119,.182,.114],[.145,.136,.059]],[.004,.030,.024,.009,.0001],'hero-open-temple',{shade:sideMat});
  add([[.052,.256,.014],[.100,.228,.108],[.118,.170,.130],[.118,.147,.124]],[.007,.018,.013,.008,.0001],'hero-temple-tip',{ink:false,lag:1.2});
  add([[.035,.265,-.030],[.010,.280,-.042],[-.034,.282,-.058],[-.050,.270,-.078]],[.003,.014,.007,.0001],'hero-crown-break',{normal:[0,1,.2],ink:false,lag:.4});
  add([[-.010,.253,-.009],[-.070,.278,-.036],[-.136,.277,-.073],[-.188,.241,-.112]],[.003,.030,.025,.009,.0001],'hero-left-crown-layer',{normal:[0,1,.3],shade:mat,lag:.7});
  add([[.024,.257,-.046],[.080,.283,-.074],[.132,.268,-.118],[.161,.227,-.161]],[.003,.033,.026,.010,.0001],'hero-right-crown-layer',{normal:[0,1,.3],shade:lightMat,lag:.8});
  for(const s of [-1,1]){
   add([[s*.086,.170,-.063],[s*.140,.172,-.091],[s*.173,.169,-.131],[s*.197,.185,-.156]],[.003,.025,.020,.007,.0001],'hero-side-break-'+s,{normal:[s,.25,-.25],ink:false,shade:sideMat,lag:1.1});
  }
 }else{
  // Longer side part and nape. Shared construction, distinct silhouette.
  add([[.039,.260,-.010],[-.011,.257,.090],[-.092,.207,.143],[-.124,.079,.105]],[.004,.039,.036,.015,.0001],'enemy-long-sweep',{shade:lightMat});
  add([[.022,.258,-.015],[-.074,.245,.072],[-.135,.160,.093],[-.144,.026,.028]],[.004,.028,.026,.012,.0001],'enemy-side-fringe',{lag:1.2});
  add([[.032,.258,.008],[.004,.236,.132],[-.049,.183,.158],[-.071,.133,.153]],[.004,.020,.018,.008,.0001],'enemy-sweep-tip');
  add([[.043,.258,-.005],[.104,.230,.077],[.144,.157,.078],[.139,.067,.025]],[.004,.028,.026,.008,.0001],'enemy-open-part',{shade:sideMat});
  for(const s of [-1,1]){
   add([[s*.091,.102,-.111],[s*.127,.036,-.153],[s*.124,-.057,-.169],[s*.144,-.087,-.160]],[.025,.031,.018,.0001],'enemy-nape-'+s,{normal:[s,.1,-.7],lag:1.3});
  }
 }
 const state={root,old,parts,setEnabled(enabled){old.visible=!enabled;root.visible=enabled;},
  update({yawVelocity=0,pitchVelocity=0,wind=0}={}){
   const yaw=THREE.MathUtils.clamp(yawVelocity,-4,4),pitch=THREE.MathUtils.clamp(pitchVelocity,-3,3);
   for(const part of parts)for(const {g,rest}of part.geometries){
    const p=g.attributes.position,cols=p.count/37;
    for(let i=0;i<p.count;i++){
     const u=Math.floor(i/cols)/36,w=smooth(u,.28,1)**2*part.lag;
     p.setXYZ(i,rest[i*3]-yaw*.003*w+wind*.001*w,rest[i*3+1],rest[i*3+2]-pitch*.0025*w);
    }
    p.needsUpdate=true;
   }
  }};
 state.setEnabled(true);actor.layeredHair=state;return state;
}
