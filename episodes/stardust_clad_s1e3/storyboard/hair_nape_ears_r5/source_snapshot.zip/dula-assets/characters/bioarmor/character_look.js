// 《9章》系列角色资产（晋升自 S1E2 R21 验收版）：canvas 动画头与面部作画。
// Curved geometry supplies the silhouette; eyes, brows and mouth share one surface.
import * as THREE from 'three';
import {SKIN,skinMaterial} from './character_finish.js';
const TAU=Math.PI*2,clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const mix=(a,b,t)=>a+(b-a)*t;
const smooth=(a,b,x)=>{const t=clamp((x-a)/(b-a));return t*t*(3-2*t);};

function outlined(parent,geometry,material,width=.0014){
  const mesh=new THREE.Mesh(geometry,material);parent.add(mesh);mesh.castShadow=true;
  const ink=new THREE.MeshBasicMaterial({color:'#3a3039',side:THREE.BackSide});
  ink.onBeforeCompile=s=>{s.vertexShader=s.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>\ntransformed += normal * ${width.toFixed(5)};`);};
  ink.customProgramCacheKey=()=>`portrait-outline-${width}`;
  mesh.add(new THREE.Mesh(geometry,ink));return mesh;
}
function headProfile(strong,kind){
  if(kind==='aoi_heroine')return [[-.069,.026,.047,.031,.021],[-.049,.052,.065,.048,.014],
    [-.010,.083,.094,.078,.003],[.050,.103,.112,.109,0],[.112,.104,.115,.117,0],
    [.166,.094,.108,.112,0],[.211,.052,.068,.072,0],[.231,.001,.001,.001,0]];
  // Aoi: wider rounded chin, higher cheeks, shallower face; not Lei's recolour.
  if(kind==='aoi')return [[-.073,.038,.052,.032,.024],[-.055,.063,.074,.050,.015],
    [-.021,.088,.096,.080,.004],[.038,.105,.114,.111,0],[.105,.107,.119,.118,0],
    [.164,.095,.108,.112,0],[.211,.052,.068,.072,0],[.231,.001,.001,.001,0]];
  return strong?
    [[-.077,.050,.069,.034,.033],[-.058,.081,.087,.06,.023],[-.018,.111,.112,.099,.004],[.042,.128,.132,.119,0],[.105,.126,.131,.128,0],[.166,.108,.112,.12,0],[.212,.065,.077,.083,0],[.232,.001,.001,.001,0]]:
    [[-.073,.025,.058,.025,.032],[-.055,.052,.080,.048,.019],[-.021,.079,.106,.082,.006],[.038,.108,.125,.112,0],[.105,.112,.125,.12,0],[.164,.095,.108,.112,0],[.211,.052,.068,.072,0],[.231,.001,.001,.001,0]];
}
function surface(strong,kind,heroine=false){
  // y, half width, front depth, back depth, forward chin offset.
  const profile=headProfile(strong,heroine?'aoi_heroine':kind);
  const positions=[],uv=[],indices=[],n=40,rows=(profile.length-1)*6;
  // Duplicate the two side seams. No triangle may interpolate from the front
  // face artwork across to a constant rear-head UV (that smears facial features).
  for(let half=0;half<2;half++){
  const start=positions.length/3;
  for(let row=0;row<=rows;row++){
    const p=row/6,k=Math.min(profile.length-2,Math.floor(p)),f=p-k;
    const a=profile[k],b=profile[k+1];
    const values=a.map((v,i)=>{
      if(i===0)return mix(v,b[i],f);
      const prev=profile[Math.max(0,k-1)][i],next=profile[Math.min(profile.length-1,k+2)][i];
      return Math.max(i===4?-1:.001,.5*((2*v)+(-prev+b[i])*f+(2*prev-5*v+4*b[i]-next)*f*f+(-prev+3*v-3*b[i]+next)*f*f*f));
    });
    const [y,rx,frontDepth,backDepth,shift]=values;
    for(let j=0;j<=n;j++){
      const angle=-Math.PI/2+half*Math.PI+j/n*Math.PI,c=Math.cos(angle),x=rx*Math.sin(angle);
      const front=clamp(c),plane=c>=0?(c*.78+Math.sin(c*Math.PI/2)*.22):c;
      const nose=(kind==='aoi'?.65:1)*Math.exp(-((x/(strong?.016:.014))**2))*
        (.016*Math.exp(-(((y-.045)/.019)**2))+.004*Math.exp(-(((y-.083)/.039)**2)))*front**12;
      const lip=.003*Math.exp(-((x/.022)**2)-((y-.004)/.017)**2)*front**8;
      const jawLift=.028*Math.max(0,1-row/6)**2*(1-c)*.5;
      positions.push(x,y+jawLift,(c>=0?frontDepth:backDepth)*plane+shift+nose+lip);
      uv.push(half===0?.5+x/.30:.015,half===0?(y+.073)/.305:.48);
      if(row<rows&&j<n){const q=start+row*(n+1)+j;indices.push(q,q+1,q+n+1,q+1,q+n+2,q+n+1);}
    }
  }
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(indices);g.computeVertexNormals();return g;
}

function scalpPoint(strong,theta,azimuth,lift=0){
  const s=Math.sin(theta),c=Math.cos(theta),rx=strong?.137:.129,rz=strong?.149:.145;
  let y=.075+(strong?.199:.178)*c;
  if(strong){
    // Soften the flat crown without pushing the front mid-scalp into the skull.
    const h=clamp(.5+.5*(.240-y)/.025);
    y=mix(.240,y,h)-.025*h*(1-h);
  }
  // The lower rear follows the nape instead of closing back into the neck.
  // This has no effect on the approved forehead/fringe surface.
  const profile=headProfile(strong);let section=profile.at(-1);
  for(let i=1;i<profile.length;i++)if(y<=profile[i][0]){
    const a=profile[i-1],b=profile[i],t=clamp((y-a[0])/(b[0]-a[0]));
    section=a.map((v,k)=>{
      if(k===0)return y;
      const prev=profile[Math.max(0,i-2)][k],next=profile[Math.min(profile.length-1,i+1)][k];
      return .5*((2*v)+(-prev+b[k])*t+(2*prev-5*v+4*b[k]-next)*t*t+(-prev+3*v-3*b[k]+next)*t*t*t);
    });break;
  }
  const rear=smooth(.25,-.55,Math.cos(azimuth))*smooth(.65,1.25,theta);
  const padding=strong?.007:.013;
  const roundedMax=(a,b)=>.5*(a+b+Math.sqrt((a-b)**2+.010**2));
  const width=mix(rx*s,roundedMax(section[1]+padding,strong?.073:.060),rear);
  const depth=mix(rz*s,roundedMax(section[3]-section[4]+padding-.007,strong?.091:.071),rear);
  return new THREE.Vector3((width+lift*s)*Math.sin(azimuth),y+lift*c,(depth+lift*s)*Math.cos(azimuth)-.007);
}
function hairColour(strong,theta,azimuth){
  const color=new THREE.Color(strong?'#30303a':'#503a3b');
  if(strong)color.lerp(new THREE.Color('#40404a'),clamp((Math.cos(azimuth+.65)+.1)/1.1)*.68);
  color.lerp(new THREE.Color(strong?'#292a32':'#423037'),smooth(.64,1,theta/hairBoundary(strong,azimuth))*smooth(.1,-.65,Math.cos(azimuth))*.35);
  return color;
}
function hairBoundary(strong,azimuth){
  const a=Math.acos(Math.cos(azimuth));
  const keys=strong?[[0,1.0],[1.0,1.34],[1.48,1.67],[1.72,1.76],[1.94,2.17],[2.35,2.33],[Math.PI,2.37]]:
    [[0,1.14],[1.0,1.48],[1.48,1.73],[1.72,1.82],[1.98,2.37],[2.4,2.53],[Math.PI,2.60]];
  for(let i=1;i<keys.length;i++)if(a<=keys[i][0]){
    const [x0,y0]=keys[i-1],[x1,y1]=keys[i];return mix(y0,y1,smooth(x0,x1,a));
  }
  return keys.at(-1)[1];
}
function hairGeometry(strong){
  const p=[],colors=[],idx=[],n=128,m=42;
  for(let i=0;i<=m;i++)for(let j=0;j<=n;j++){
    const a=j/n*TAU,front=Math.cos(a);
    const end=hairBoundary(strong,a);
    const wave=(strong?.012:.026)*(Math.sin(a*(strong?21:11))+.3*Math.sin(a*17+.7))*(i/m)**9;
    const point=scalpPoint(strong,i/m*end+wave,a);p.push(...point.toArray());
    const color=hairColour(strong,i/m*end+wave,a);
    colors.push(color.r,color.g,color.b);
    if(i<m&&j<n){const k=i*(n+1)+j;idx.push(k,k+n+1,k+1,k+1,k+n+1,k+n+2);}
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));g.setIndex(idx);g.computeVertexNormals();return g;
}
function sweptTuft(parent,a,b,c,width,color){
  const curve=new THREE.QuadraticBezierCurve3(new THREE.Vector3(...a),new THREE.Vector3(...b),new THREE.Vector3(...c));
  const points=[],indices=[],n=16,sides=8;
  for(let i=0;i<=n;i++){
    const u=i/n,p=curve.getPoint(u),t=curve.getTangent(u).normalize();
    const right=new THREE.Vector3(0,0,1).cross(t).normalize(),up=t.clone().cross(right);
    const r=width*Math.pow(1-u,.75)+.00015;
    for(let j=0;j<=sides;j++){
      const angle=j/sides*TAU,v=p.clone().addScaledVector(right,Math.cos(angle)*r).addScaledVector(up,Math.sin(angle)*r*.40);points.push(...v.toArray());
      if(i<n&&j<sides){const k=i*(sides+1)+j;indices.push(k,k+sides+1,k+1,k+1,k+sides+1,k+sides+2);}
    }
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(points,3));g.setIndex(indices);g.computeVertexNormals();
  outlined(parent,g,new THREE.MeshBasicMaterial({color,side:THREE.DoubleSide}),.0006);
}
function hairPanel(parent,strong,start,end,thetaEnd,width,color){
  const p=[],colors=[],idx=[],n=24,m=8,base=new THREE.Color(color),shade=base.clone().multiplyScalar(.86);
  for(let i=0;i<=n;i++)for(let j=0;j<=m;j++){
    const u=i/n,v=j/m*2-1,az=mix(start,end,u)+v*width*Math.pow(1-u,.65);
    const theta=mix(.30,thetaEnd,u),bulge=.002+.007*Math.sin(Math.PI*u)*(1-v*v);
    const point=scalpPoint(strong,theta,az,bulge);p.push(...point.toArray());
    const c=base.clone().lerp(shade,clamp((v+.15)*.75));colors.push(c.r,c.g,c.b);
    if(i<n&&j<m){const k=i*(m+1)+j;idx.push(k,k+m+1,k+1,k+1,k+m+1,k+m+2);}
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(p,3));
  g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));g.setIndex(idx);g.computeVertexNormals();
  const mesh=new THREE.Mesh(g,new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.DoubleSide}));parent.add(mesh);return mesh;
}

function rearHairLock(parent,strong,a0,a1,start,end,width,color){
  const positions=[],colors=[],indices=[],n=24,m=8;
  const base=new THREE.Color(color),shade=base.clone().multiplyScalar(.86);
  for(let i=0;i<=n;i++)for(let j=0;j<=m;j++){
    const u=i/n,v=j/m*2-1,tip=Math.pow(Math.max(0,1-u),.60);
    const theta=mix(start,end,u),a=mix(a0,a1,smooth(0,1,u))+v*width*tip;
    // Roots lie within the cap; the body and tips stay attached to the same scalp.
    const lift=-.0015+(strong?.005:.010)*Math.sin(Math.PI*u)*(1-v*v);
    const p=scalpPoint(strong,theta,a,lift);positions.push(...p.toArray());
    const c=hairColour(strong,theta,a).lerp(base.clone().lerp(shade,smooth(-.2,1,v)*.7),
      smooth(.08,.4,u)*smooth(1,.70,Math.abs(v))*.62);
    colors.push(c.r,c.g,c.b);
    if(i<n&&j<m){const q=i*(m+1)+j;indices.push(q,q+m+1,q+1,q+1,q+m+1,q+m+2);}
  }
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));g.setIndex(indices);g.computeVertexNormals();
  const mesh=new THREE.Mesh(g,new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.DoubleSide}));parent.add(mesh);
}

function paintFace(ctx,strong,emotion,blink,lip,acting,gaze,kind,style={}){
  const g=ctx;g.setTransform(2,0,0,2,0,0);g.clearRect(0,0,512,512);
  const fear=clamp(acting?.fear??(emotion==='scared'?.8:emotion==='worry'?.35:0));
  const focus=clamp(acting?.focus??(['determined','declare','angry'].includes(emotion)?.75:0));
  const smile=emotion==='laugh'?1:clamp(acting?.smile??0),close=clamp(acting?.blink??blink);
  const aoi=kind==='aoi',palette=SKIN[kind],skin=palette.base;
  g.fillStyle=skin;g.fillRect(0,0,512,512);
  // The prior fixed forehead/cheek polygons looked like different skin patches.
  // Keep a single base here; silhouette, eyes and nose provide the form.
  const eyeY=style.eyeY??(strong?242:aoi?251:244),dx=style.eyeSpacing??(strong?95:aoi?87:90);
  const gazeX=clamp(acting?.gazeX??gaze.x,-1,1),gazeY=clamp(acting?.gazeY??gaze.y,-1,1);
  for(const side of [-1,1]){
    const cx=256+side*dx,openness=1-close;
    const h=(strong?24:aoi?23:32)*(1+.20*fear-.23*focus),upper=h*openness,lower=h*(aoi?.34:.45)*openness;
    const isClosed=openness<.045||smile>.5;
    g.save();g.translate(cx,eyeY);g.scale(side*(style.eyeWidth??1),style.eyeHeight??1);
    const eye=()=>{g.beginPath();g.moveTo(-51,1);g.bezierCurveTo(-26,-upper,20,-upper*1.05,53,-7*openness);g.quadraticCurveTo(28,lower,-22,lower*.86);g.quadraticCurveTo(-41,lower*.55,-51,1);g.closePath();};
    if(!isClosed){
      g.save();eye();g.clip();g.fillStyle='#fff7e8';g.fillRect(-58,-48,116,90);
      const eyeShade=g.createLinearGradient(0,-h,0,5);
      eyeShade.addColorStop(0,'#d9c9bc');eyeShade.addColorStop(.55,'#fff7e8');
      eyeShade.addColorStop(1,'#fff7e8');g.fillStyle=eyeShade;g.fillRect(-58,-48,116,90);
      const ix=gazeX*side*16-3,iy=gazeY*10,ir=strong?16:aoi?19:23;
      const iris=g.createLinearGradient(0,-24,0,25);iris.addColorStop(0,kind==='aoi'?'#244846':strong?'#594139':'#594642');iris.addColorStop(.52,kind==='aoi'?'#467e70':strong?'#91603d':'#a67944');iris.addColorStop(1,kind==='aoi'?'#97bea1':strong?'#d39a51':'#ddb469');
      g.fillStyle=iris;g.beginPath();g.ellipse(ix,iy,ir,strong?26:34,0,0,TAU);g.fill();
      g.strokeStyle='#4d3734';g.lineWidth=2.3;g.stroke();
      g.fillStyle='#302b34';g.beginPath();g.ellipse(ix,iy-1,(strong?7:10)*(acting?.pupil??1),strong?18:23,0,0,TAU);g.fill();
      g.fillStyle='#fffaf0';g.beginPath();g.ellipse(ix-6*side,iy-13,4.5,6,-.3,0,TAU);g.fill();
      g.globalAlpha=.6;g.beginPath();g.arc(ix+8*side,iy+13,2.5,0,TAU);g.fill();g.restore();
    }
    g.strokeStyle='#392b31';g.lineCap='round';g.lineWidth=strong?6:5.5;
    g.beginPath();g.moveTo(-51,1);
    if(isClosed){g.quadraticCurveTo(2,smile?-h*.9:5,53,-3);}
    else{g.bezierCurveTo(-26,-upper,20,-upper*1.05,53,-7*openness);}
    g.stroke();
    if(!isClosed){
      g.lineWidth=1.65;g.strokeStyle=palette.line;g.beginPath();g.moveTo(-17,lower*.94);g.quadraticCurveTo(25,lower+1,44,3);g.stroke();
      g.fillStyle='#392b31';g.beginPath();g.moveTo(39,-upper*.6);g.lineTo(59,-10*openness);g.lineTo(51,0);g.fill();
      if(style.lashes){g.strokeStyle='#392b31';g.lineWidth=2.4;for(const [x,y,ex,ey] of [[43,-10,54,-18],[50,-6,61,-11]]){g.beginPath();g.moveTo(x,y*openness);g.lineTo(ex,ey*openness);g.stroke();}}
    }
    g.restore();
    // Brows are tapered shapes, with independently controlled inner and outer ends.
    const by=eyeY-(strong?40:aoi?40:51)-(fear*3),asym=(acting?.browAsym??.08)*side*6;
    const inner=by+focus*17-fear*19+asym,outer=by-3+fear*6;
    g.fillStyle=aoi?'#294348':strong?'#343039':'#644339';g.beginPath();
    g.moveTo(256+side*(dx-43),inner);g.quadraticCurveTo(cx,by-8,256+side*(dx+51),outer);
    g.lineTo(256+side*(dx+48),outer+(strong?8:4));
    g.quadraticCurveTo(cx,by+(strong?9:1),256+side*(dx-41),inner+(strong?12:7));g.closePath();g.fill();
  }
  // Short nose accents follow the actual nose volume; no large drawn hook.
  g.strokeStyle=style.noseLine??palette.line;g.lineWidth=style.noseWidth??1.8;g.lineCap='round';
  g.beginPath();g.moveTo(262,312);g.quadraticCurveTo(268,319,259,321);g.stroke();
  const jaw=clamp(Math.max(lip.jaw??0,acting?.jawOverride??0));
  const w=(strong?30:aoi?24:27)*clamp(lip.width??1,.7,1.35)*(style.mouthWidth??1),my=aoi?370:378;
  const corner=smile?-8*smile:focus?2:fear?3:0;
  if(jaw<.035){
    g.strokeStyle=strong?'#8d5b4f':'#a16e61';g.lineWidth=2.6;g.beginPath();g.moveTo(256-w,my+corner);g.quadraticCurveTo(256,my+(smile?4:fear?-2:0),256+w,my+corner);g.stroke();
  }else{
    const top=1+jaw*11,bottom=3+jaw*(strong?42:38)*(style.mouthHeight??1);
    g.beginPath();g.moveTo(256-w,my+corner);g.bezierCurveTo(243,my-top,269,my-top,256+w,my+corner);
    g.bezierCurveTo(271,my+bottom,241,my+bottom,256-w,my+corner);g.closePath();
    g.fillStyle='#69443f';g.fill();g.save();g.clip();
    if(jaw>.32){g.fillStyle='#fff1d8';g.fillRect(216,my-top,80,5+focus*3);}
    if(jaw>.42){g.fillStyle='#b76d71';g.beginPath();g.ellipse(256,my+bottom*.82,w*.70,7,0,0,TAU);g.fill();}
    g.restore();g.strokeStyle=strong?'#986354':'#ac7563';g.lineWidth=1.4;g.stroke();
  }
  if(jaw>.15){g.strokeStyle=strong?'#c6967c':'#d8b39b';g.lineWidth=1.3;g.beginPath();g.moveTo(251,402+jaw*14);g.quadraticCurveTo(257,404+jaw*14,262,402+jaw*14);g.stroke();}
}

export function animatedHead(body,kind,height,{heroine=false}={}){
  const strong=kind==='hong',head=new THREE.Group();head.name=`${kind}_animated_head`;head.position.y=height+.026;body.add(head);
  const skin=skinMaterial(kind);
  // A single restrained under-chin value separates the head from the neck.
  const neckSkin=skin.clone();neckSkin.color.multiplyScalar(.92);
  const neck=new THREE.Mesh(new THREE.CylinderGeometry(strong?.063:.048,strong?.077:.063,.148,32),neckSkin);
  neck.position.set(0,height-.05,-.018);body.add(neck);
  const canvas=document.createElement('canvas');canvas.width=canvas.height=1024;
  const ctx=canvas.getContext('2d'),texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=8;
  // A normal-expanded hull also outlines the concave nose/cheek boundary inside
  // the face. Keep the skin contour clean instead of drawing that false crease.
  const skull=new THREE.Mesh(surface(strong,kind,heroine),new THREE.MeshBasicMaterial({map:texture}));head.add(skull);skull.castShadow=true;
  for(const side of [-1,1]){
    const ear=new THREE.Mesh(new THREE.SphereGeometry(1,32,24),skin);
    ear.scale.set(.019,.032,.014);ear.position.set(side*(strong?.124:.110),.043,-.020);head.add(ear);
    const inner=new THREE.Mesh(new THREE.SphereGeometry(1,24,16),new THREE.MeshBasicMaterial({color:SKIN[kind].inner}));
    inner.scale.set(.002,.016,.006);inner.position.set(side*(strong?.141:.127),.045,-.013);head.add(inner);
  }
  if(kind==='aoi'){
    const cap=hairGeometry(false),colors=cap.attributes.color;
    for(let i=0;i<colors.count;i++)colors.setXYZ(i,.035,.085,.10);
    outlined(head,cap,new THREE.MeshBasicMaterial({vertexColors:true}),.0007);
    for(const side of [-1,1])hairPanel(head,false,side*1.35,side*1.62,heroine?2.15:2.30,.26,'#24393e');
    const fringe=heroine?[[-.90,-1.0,1.65,.23],[-.50,-.55,1.30,.23],[-.12,-.18,1.30,.19],[.24,.38,1.33,.20],[.66,.96,1.62,.20]]:[[-.86,-.98,1.65,.27],[-.43,-.7,1.5,.25],[.02,-.35,1.42,.26],[.45,.69,1.55,.23]];
    for(const [a,b,t,w] of fringe)
      hairPanel(head,false,a,b,t,w,'#294348');
    for(let i=0;i<11;i++){const a=1.72+i*.285;rearHairLock(head,false,a-.14,a,.65,2.52,.19,'#24393e');}
    // Hair clip is rigidly attached above the temple; no hanging accessory.
    const clip=new THREE.Mesh(new THREE.BoxGeometry(.028,.008,.009),new THREE.MeshBasicMaterial({color:'#d4b96e'}));
    clip.position.set(.092,.139,.091);clip.rotation.z=-.35;head.add(clip);
    if(heroine){
      // A tied, swept long silhouette with roots buried in the rear cap.
      // It follows the head; it is not a disconnected billboard or a new face.
      const tail=new THREE.Group();tail.name='aoi_long_hair';head.add(tail);
      sweptTuft(tail,[.070,.135,-.105],[.226,.102,-.237],[.192,-.270,-.205],.079,'#294348');
      sweptTuft(tail,[.081,.122,-.110],[.254,.017,-.215],[.251,-.221,-.171],.058,'#335259');
      sweptTuft(tail,[.096,.126,-.128],[.155,.021,-.258],[.157,-.232,-.216],.055,'#233c42');
      for(const [x,y,z,rz] of [[.094,.139,.098,-.5],[.107,.151,.088,.5]]){
        const leaf=new THREE.Mesh(new THREE.SphereGeometry(1,16,12),new THREE.MeshBasicMaterial({color:'#bbcc81'}));
        leaf.scale.set(.020,.008,.004);leaf.position.set(x,y,z);leaf.rotation.z=rz;head.add(leaf);
      }
    }
  }else{
  outlined(head,hairGeometry(strong),new THREE.MeshBasicMaterial({vertexColors:true}),.0007);
  if(strong){
    // A close-cropped, flatter silhouette. The hairline is part of the cap;
    // avoid long fringe panels or detached individual "stubble" tubes.
    for(const side of [-1,1])hairPanel(head,true,side*1.4,side*1.48,1.71,.08,'#33313c');
    // Short, overlapping growth groups descend behind the ears to the nape.
    for(let i=0;i<17;i++){
      const a=1.88+i*.16,end=hairBoundary(true,a);
      rearHairLock(head,true,a-.045,a,end-.25,end+.028+.016*Math.sin(i*2.1),.075,'#34343d');
    }
  }else{
    const locks=[[-.94,-1.04,1.80,.24],[-.63,-.67,1.53,.29],[-.28,-.21,1.46,.28],[.08,.26,1.68,.31],[.47,.66,1.48,.27],[.91,1.06,1.81,.22]];
    locks.forEach(([a,b,t,w],i)=>hairPanel(head,false,a,b,t,w,i%2?'#674748':'#5c4042'));
    for(const side of [-1,1])hairPanel(head,false,side*1.38,side*1.62,1.85,.23,'#4a353c');
    // Broad back locks overlap from crown to nape, with staggered lengths.
    for(let i=0;i<9;i++){
      const a=1.87+i*.32;
      rearHairLock(head,false,a-.22+.12*Math.sin(i*1.6),a+.035*Math.sin(i),.42+.13*Math.sin(i*.8),hairBoundary(false,a)+.09+.055*Math.sin(i*2.3),.26,i%2?'#5c4042':'#51393d');
    }
    for(const side of [-1,1])rearHairLock(head,false,side*1.78,side*1.97,1.28,2.52,.18,'#51393d');
    sweptTuft(head,[-.025,.237,-.008],[.021,.285,-.010],[.066,.262,.005],.018,'#5c4042');
    sweptTuft(head,[-.047,.222,-.039],[-.024,.274,-.035],[.015,.261,-.028],.014,'#51383e');
  }
  }
  let emotion='neutral',blink=0,lip={jaw:0,width:1},acting=null,last='',style={};
  const gaze={x:0,y:0};
  function draw(){
    const key=JSON.stringify([emotion,blink,lip,acting,gaze,style]);if(key===last)return;last=key;
    paintFace(ctx,strong,emotion,blink,lip,acting,gaze,kind,style);texture.needsUpdate=true;
  }
  draw();
  return {head,skull,
    setStyle(value={}){style={...value};last='';},
    setEmotion(e='neutral',b=0){emotion=e;blink=b;},
    setActing(a){acting=a;},
    lookAtWorld(target){head.updateWorldMatrix(true,false);const local=head.worldToLocal(target.clone());gaze.x=clamp(local.x/Math.max(.3,Math.abs(local.z)),-1,1)*.55;gaze.y=clamp(-local.y/Math.max(.3,Math.abs(local.z)),-1,1)*.5;},
    applyLip(value){lip=value;draw();return {jaw:value.jaw};},
    mouth:{apply(value){lip=value;draw();return {jaw:value.jaw};}},
  };
}
