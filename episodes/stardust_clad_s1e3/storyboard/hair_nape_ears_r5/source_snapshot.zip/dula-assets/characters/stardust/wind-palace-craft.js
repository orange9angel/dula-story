import * as THREE from 'three';
import {XiaozaoCraft,YekariCraft} from './characters.js';
import {applyPalaceClad} from './palace-clad.js';
import {applyPalaceCuirass,applyPalaceAnatomy} from './body-clad.js';
import {applyPalaceGauntlets} from './gauntlet-clad.js';
import {applyPalaceLowerClad} from './lower-clad.js';
import {createArmorEnvironment,applyMetalClad,refinePalaceLimbs} from './metal-clad.js';
import {applyPalaceArms,applySingleShoulders,removeCladGlow} from './palace-arms.js';
import {applyConnectedPelvis} from './connected-pelvis.js';
import {applyPalacePortrait} from './palace-portrait.js';
import {applyShadedPortrait} from './shaded-portrait.js';
import {applySoftPortrait} from './soft-portrait.js';
import {createRegalMetalEnvironment,applyOrnamentMetal} from './ornament-metal.js';

export class XiaozaoPalaceCraft extends XiaozaoCraft {}
export class JianwangPalaceCraft extends YekariCraft {}
export const WIND_DIMS={
 xiaozao:{hipIdle:.81,shoulderY:1.32,shoulderHalf:.125,hipHalf:.072,legA:.39,legB:.39,armA:.19,armB:.18,footY:.078},
 jianwang:{hipIdle:.93,shoulderY:1.52,shoulderHalf:.125,hipHalf:.068,legA:.49,legB:.49,armA:.21,armB:.20,footY:.09}
};
function silverDisc(actor,env){
 // Keep the actual forearm anchor. The shield has thickness, an open lattice
 // and a beveled cutting rim; the original flat decorative disc stays hidden.
 const old=actor.bracerDiscL;old.visible=false;
 const root=new THREE.Group();root.name='wind-sieve-shield';
 old.parent.add(root);root.position.copy(old.position);root.quaternion.copy(old.quaternion);
 const metal=new THREE.MeshPhysicalMaterial({color:'#b5d2df',metalness:1,roughness:.25,envMap:env,envMapIntensity:1.25});
 const dark=new THREE.MeshPhysicalMaterial({color:'#34536a',metalness:.85,roughness:.36,envMap:env});
 const piece=(g,m)=>{const o=new THREE.Mesh(g,m);o.castShadow=true;root.add(o);return o;};
 for(const r of [.224,.20,.075]){const o=piece(new THREE.TorusGeometry(r,r===.224?.012:.006,10,64,r>.1?Math.PI*2-.26:Math.PI*2),metal);o.rotation.x=Math.PI/2;}
 for(let i=0;i<12;i++){
  const a=i*Math.PI/6,pts=[.075,.12,.19,.22].map(r=>new THREE.Vector3(Math.cos(a)*r,.003+Math.sin(r*8)*.01,Math.sin(a)*r));
  piece(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts),20,.005,7,false),i%2?metal:dark);
 }
 const boss=piece(new THREE.SphereGeometry(.072,32,20),metal);boss.scale.y=.3;
 const tooth=piece(new THREE.BoxGeometry(.033,.015,.009),metal);tooth.position.set(.210,.009,-.026);tooth.rotation.y=.18;
 const anchor=new THREE.Object3D();anchor.position.set(.214,.013,-.023);root.add(anchor);
 actor.windDisc={root,anchor,old};
}
function identities(actor,hero){
 const head=actor.headGroup,skull=actor.face.skull;
 // Different facial proportions, retaining the mature curved face/UV rig.
 const g=skull.geometry.clone(),p=g.attributes.position;
 for(let i=0;i<p.count;i++){
  let x=p.getX(i),y=p.getY(i),z=p.getZ(i);
  const jaw=THREE.MathUtils.smoothstep(.055-y,0,.10);
  x*=hero?1-.06*jaw:1-.11*jaw;
  if(z>.04){
   const front=Math.max(0,1-Math.abs(x)/.11);
   z+=front**4*.007*Math.exp(-((x/.017)**2)-((y-.046)/.024)**2);
   z-=.0045*Math.exp(-(((Math.abs(x)-.049)/.026)**2)-((y-.083)/.025)**2);
   z+=.004*Math.exp(-(((Math.abs(x)-.058)/.030)**2)-((y-.028)/.025)**2);
  }
  if(!hero)y=.045+(y-.045)*1.035;
  p.setXYZ(i,x,y,z);
 }
 g.computeVertexNormals();skull.geometry=g;
 const hair=actor.softPortrait.hair;
 hair.traverse(m=>{if(m.isMesh){const previous=m.material;m.material=previous.clone();m.material.onBeforeCompile=previous.onBeforeCompile;m.material.customProgramCacheKey=previous.customProgramCacheKey;m.material.color.set(hero?'#29464c':'#504455');}});
 skull.material.color.set(hero?'#f9e5d9':'#eee0df');
 skull.material.onBeforeCompile=shader=>{
  shader.vertexShader='varying vec3 windSkinNormal;\n'+shader.vertexShader;
  shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nwindSkinNormal=normalize(mat3(modelMatrix)*normal);');
  shader.fragmentShader='varying vec3 windSkinNormal;\n'+shader.fragmentShader;
  shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
   float value=dot(normalize(windSkinNormal),normalize(vec3(-.63,.52,.65)));
   float halfshade=1.-smoothstep(.10,.85,value);
   float deep=1.-smoothstep(-.45,.02,value);
   diffuseColor.rgb*=mix(vec3(1.),vec3(.71,.62,.66),halfshade*.48);
   diffuseColor.rgb*=mix(vec3(1.),vec3(.65,.57,.65),deep*.45);`);
 };
 skull.material.customProgramCacheKey=()=> 'wind-curved-skin-v2';
 skull.material.needsUpdate=true;
 if(hero){
  for(const m of hair.children)if(m.name.includes('nape')){m.scale.y=.65;m.position.y=.025;}
  const previous=actor.palacePortrait.afterPaint;
  actor.palacePortrait.afterPaint=(ctx,state)=>{
   previous(ctx,state);
   ctx.save();ctx.setTransform(2,0,0,2,0,0);
   // The established mole and less arched lids distinguish the young guardian.
   ctx.fillStyle='#50414b';ctx.beginPath();ctx.ellipse(160,293,2.7,3.4,0,0,Math.PI*2);ctx.fill();
   ctx.restore();
  };
 }else{
  // Expose the brow on the adversary instead of repeating the hero's fringe.
  for(const m of hair.children){
   if(m.name==='enemy-side-swept-fringe'){m.rotation.z=-.20;m.position.y=.027;}
   if(m.name==='enemy-long-left-fringe'){m.scale.y=.86;m.position.y=.020;}
  }
 }
 actor.face.setActing({smile:0,focus:hero?.45:.65,fear:0});
}
export async function finishWindPalaceCharacters(actors,renderer,textureUrl){
 const environment=createArmorEnvironment(renderer),regal=createRegalMetalEnvironment(renderer);
 for(const [name,a] of Object.entries(actors)){
  const hero=name==='xiaozao';
  // Explicit composition of the accepted construction chain. Every stage is
  // applied to these instances only; previous episodes retain their own look.
  applyPalaceClad(a,hero?'xiaozao':'yekari');
  // Shape family is independent of palette and portrait identity.
  if(hero)a.palaceKind='aoao';
  applyPalaceCuirass(a,{integratedShoulders:true,signature:true});
  applyPalaceGauntlets(a,{distinct:true,signature:true});
  applyPalaceLowerClad(a,{distinct:true,signature:true});
  await applyMetalClad(a,{url:textureUrl,environment:environment.texture,cleanMetal:true});
  refinePalaceLimbs(a);applyPalaceAnatomy(a);applyConnectedPelvis(a);
  applyPalaceArms(a);applySingleShoulders(a);applyOrnamentMetal(a,regal.texture);
  if(hero)a.palaceKind='xiaozao';
  applyPalacePortrait(a);applyShadedPortrait(a);applySoftPortrait(a);removeCladGlow(a);
  a.anatomicalHands=true;
  if(hero){
   for(const o of [a.torso,a.anatomy.pelvis,...Object.values(a.limbs).map(l=>l.mesh)]){
    o.material=o.material.clone();o.material.color.set('#263748');
   }
  }
  const hidden=[a.palaceRatchet,a.sickle,a.returnBlade,a.cape?.m,a.cape?.mesh,...(a.chainLinks??[])].filter(Boolean);
  if(hero)silverDisc(a,regal.texture);
  a.mesh.traverse(m=>{
   if(!m.isMesh||!m.userData.metalClad)return;
   m.material=m.material.clone();
   const edge=/rim|rib|ridge|arc|bridge|edge|knuckle|finger/.test(m.name)||m.geometry.type==='TubeGeometry'||m.geometry.type==='TorusGeometry';
   m.material.color.set(hero?(edge?'#c2e2ec':'#8baebc'):(edge?'#b1a3c9':'#43364e'));
   if(hero)m.material.roughness=Math.max(.29,m.material.roughness);
   m.material.envMapIntensity=hero?1.35:1.15;
  });
  identities(a,hero);
  a.updateWindAppearance=t=>{
   a.softPortrait.update(t);
   for(const o of hidden)o.visible=false;
   if(hero)a.windDisc.old.visible=false;
  };
  a.updateWindAppearance(0);
 }
 return {environment,regal};
}
