import * as THREE from 'three';
import {LimbSurface,ringsGeometry,mesh,ellipsoid,jointInk,shoeGeometry} from '../../lib/craft3d/surface.js';
import {ArticulatedHand} from '../../lib/craft3d/hand.js';
import {twoBone} from '../../lib/craft3d/pose.js';
import {paintDrawnFace} from '../../lib/craft3d/drawn-face.js';
import {addGraphicHair} from '../../lib/craft3d/graphic-hair.js';
import {XiaozaoCraft,YekariCraft} from './characters.js';
import {applyPalaceCuirass} from './body-clad.js';
const V=a=>new THREE.Vector3(...a), obj=a=>({x:a.x,y:a.y,z:a.z});
const clamp=THREE.MathUtils.clamp, mix=THREE.MathUtils.lerp;
function finitePose(value,label='pose'){
 if(typeof value==='number'&&!Number.isFinite(value))throw new Error(`Non-finite ${label}`);
 if(value&&typeof value==='object')for(const [k,v]of Object.entries(value))finitePose(v,`${label}.${k}`);
}
const cloth=c=>new THREE.MeshToonMaterial({color:c});
const skin=c=>{
 const m=new THREE.MeshBasicMaterial({color:c,toneMapped:false});
 m.onBeforeCompile=s=>{
  s.vertexShader='varying vec3 fleshN;\n'+s.vertexShader;
  s.vertexShader=s.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nfleshN=normalize(mat3(modelMatrix)*normal);');
  s.fragmentShader='varying vec3 fleshN;\n'+s.fragmentShader;
  s.fragmentShader=s.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
   float shade=1.-smoothstep(.14,.20,dot(normalize(fleshN),normalize(vec3(-.5,.65,.75))));
   diffuseColor.rgb*=mix(vec3(1.),vec3(.72,.60,.65),shade*.52);`);
 };m.customProgramCacheKey=()=> 'wind-flesh-plane-v1';return m;
};
function cat(a,b,c,d,t){return .5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t);}
function dense(profile){
 const out=[];for(let k=0;k<profile.length-1;k++)for(let i=0;i<6;i++){
  const u=i/6;out.push(profile[k].map((x,j)=>j===0?mix(x,profile[k+1][j],u):cat(profile[Math.max(0,k-1)][j],x,profile[k+1][j],profile[Math.min(profile.length-1,k+2)][j],u)));
 }out.push(profile.at(-1));return out;
}
function stroke(parent,points,color,r=.0015){
 const g=new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(V)),24,r,5,false);
 return mesh(parent,g,new THREE.MeshBasicMaterial({color}),false);
}
function portrait(parent,kind){
 const enemy=kind==='jianwang',girl=kind==='weihe',root=new THREE.Group();parent.add(root);
 const base=enemy?'#d9c6bf':girl?'#efd0b4':'#efc5a4',cv=document.createElement('canvas');cv.width=cv.height=1024;
 const tex=new THREE.CanvasTexture(cv);tex.colorSpace=THREE.SRGBColorSpace;tex.anisotropy=8;
 const ctx=cv.getContext('2d');
 const levels=[
 [-.005,.016,.042,.020],[.012,.040,.063,.005],[.045,.071,.085,-.034],
 [.090,.096,.100,-.075],[.145,.111,.108,-.096],[.192,.113,.112,-.106],
 [.245,.106,.104,-.104],[.295,.084,.078,-.082],[.325,.041,.030,-.030],[.335,.001,0,0]
 ];
 // Smooth face rings with a narrow median nose, rounded cheek planes and chin.
 const pos=[],uv=[],ix=[],rows=100,sides=96;
 for(let i=0;i<=rows;i++){
  const y=mix(levels[0][0],levels.at(-1)[0],i/rows);
  let k=levels.findIndex(a=>a[0]>=y);k=Math.max(1,k);
  const u=(y-levels[k-1][0])/(levels[k][0]-levels[k-1][0]),s=u*u*(3-2*u);
  const a=levels[k-1],b=levels[k],interp=j=>cat(levels[Math.max(0,k-2)][j],a[j],b[j],levels[Math.min(levels.length-1,k+1)][j],u);
  const w=Math.max(.001,interp(1))*(enemy?.86:girl?.98:1),f=interp(2),back=interp(3);
  for(let j=0;j<=sides;j++){
   const t=-Math.PI+j/sides*2*Math.PI,c=Math.cos(t),x=w*Math.sin(t);
   let z=(f+back)*.5+(f-back)*.5*(c>0?Math.pow(c,.74):c);
   if(c>0){
    z+=(enemy?.022:.018)*Math.exp(-((x/.015)**2+((y-.122)/(y>.122?.038:.013))**2));
    z-=.003*Math.exp(-(((Math.abs(x)-.052)/.034)**2+((y-.185)/.014)**2));
    z+=.002*Math.exp(-((x/.030)**2+((y-.074)/.012)**2));
   }
   pos.push(x,y,z);uv.push(c>0?.5+x/.42:.015,c>0?.5+(y-.165)/.42:.985);
   if(i<rows&&j<sides){const q=i*(sides+1)+j;ix.push(q,q+1,q+sides+1,q+1,q+sides+2,q+sides+1);}
  }
 }
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geo.setIndex(ix);geo.computeVertexNormals();
 const faceMat=new THREE.MeshBasicMaterial({map:tex,toneMapped:false});
 // World-relative soft planar light, separate from painted features.
 faceMat.onBeforeCompile=s=>{
  s.vertexShader='varying vec3 faceN;\n'+s.vertexShader;
  s.vertexShader=s.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nfaceN=normalize(mat3(modelMatrix)*normal);');
  s.fragmentShader='varying vec3 faceN;\n'+s.fragmentShader;
  s.fragmentShader=s.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
   float shadow=1.-smoothstep(.14,.20,dot(normalize(faceN),normalize(vec3(-.5,.65,.75))));
   diffuseColor.rgb*=mix(vec3(1.),vec3(.72,.60,.65),shadow*.52);`);
 };faceMat.customProgramCacheKey=()=> 'wind-face-plane-v1';
 mesh(root,geo,faceMat,false);
 for(const side of [-1,1]){
  ellipsoid(root,[side*.111,.147,.002],[.014,.029,.017],skin(base),false);
  stroke(root,[[side*.117,.164,.015],[side*.124,.150,.020],[side*.118,.135,.016]],'#b6877a',.0012);
 }
 const config={skin:base,eyes:[[-.047,.187,.034,enemy?.014:girl?.022:.022],[.047,.187,.034,enemy?.014:girl?.022:.022]],
 brows:[[-.049,.221,.032],[.049,.221,.032]],mouth:[0,.075,enemy?.024:.022],
 noseY:.122,iris:enemy?'#896478':girl?'#938346':'#467d8b',irisTop:'#263945',irisLight:enemy?'#be98a9':'#a1d2c8',lashes:!enemy,browWidth:enemy?.004:.005,
 browColor:enemy?'#4e4552':'#293d43',ink:'#1d2839'};
 const locks=[],add=(points,width,color=0,extra={})=>locks.push({points,width,color,depth:.10,...extra});
 const C=[0,.204,-.009],R=[.120,.145,.121];
 const scalp=(a,l)=>[R[0]*Math.sin(l)*Math.sin(a),C[1]+R[1]*Math.cos(l),C[2]+R[2]*Math.sin(l)*Math.cos(a)];
 // Unequal major masses; broad, very shallow sections avoid cylindrical locks.
 for(let i=0;i<9;i++){
  const a=.75+i/8*4.75,l=1.5+.42*Math.max(0,-Math.cos(a)),p=scalp(a,l);
  p[1]-=enemy?.04:girl?.10:.015;p[0]+=Math.sin(a)*.013;
  add([scalp(a,.35),scalp(a,.9),scalp(a,l-.25),p],.030+(i%3)*.004,i%3===1?1:0);
 }
 if(enemy){
  add([[-.015,.343,.003],[-.085,.301,.100],[-.100,.230,.102],[-.126,.127,.045]],.044,1);
  add([[.015,.34,.005],[.083,.306,.101],[.112,.230,.080],[.129,.145,.018]],.050);
  add([[.002,.341,.006],[.028,.307,.111],[.045,.250,.119],[.025,.211,.116]],.024,1);
 }else{
  add([[.045,.335,.018],[.009,.305,.115],[-.043,.263,.131],[-.077,.190,.103]],.042,1);
  add([[.058,.325,.008],[.079,.292,.106],[.110,.238,.100],[.117,.178,.045]],.038);
  add([[.020,.334,.015],[-.043,.307,.103],[-.095,.255,.100],[-.120,.206,.048]],.045);
 }
 // Rear ends share a delayed bend; roots remain embedded in the skull.
 if(girl||enemy)for(const side of [-1,1])add([[side*.060,.273,-.100],[side*.094,.150,-.110],[side*.080,.040,-.118],[side*.105,-.070,-.080]],.032,0,{tail:true});
 const proxy={mesh:root,bones:{head:root}};
 const hair=addGraphicHair(proxy,{center:C,radii:R,hem:[[-180,.10],[-110,.13],[-65,.21],[-25,.262],[25,.267],[65,.215],[110,.13],[180,.10]],locks,
 colors:enemy?['#655f70','#817b8b']:girl?['#47433d','#65624c']:['#253e49','#405d68'],
 flat:true,cel:{shadow:enemy?'#3e394c':'#162d37',light:enemy?'#b4a2b0':'#77979c'},tailPivot:[0,.20,-.07]});
 const tips=hair.children.filter(m=>m.isMesh&&m.geometry.attributes.position.count===57*21).map(m=>({geo:m.geometry,rest:m.geometry.attributes.position.array.slice()}));
 return {root,hair,update(s={}){
  const state={blink:0,focus:0,fear:0,gaze:[0,0],jaw:0,width:1,smile:0,...s};
  ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle=base;ctx.fillRect(0,0,1024,1024);
  ctx.setTransform(1024/.42,0,0,-1024/.42,512,512+1024*.165/.42);
  paintDrawnFace(ctx,config,state);
  if(state.strain>.72&&state.jaw<.15){
   ctx.fillStyle='#f2e5cd';ctx.strokeStyle='#754e4c';ctx.lineWidth=.0013;
   ctx.beginPath();ctx.moveTo(-.022,.077);ctx.quadraticCurveTo(0,.082,.022,.078);ctx.lineTo(.019,.071);ctx.quadraticCurveTo(0,.069,-.020,.071);ctx.closePath();ctx.fill();ctx.stroke();
  }
  ctx.fillStyle=enemy?'#c3a9a8':'#d5a186';ctx.beginPath();ctx.moveTo(.003,.151);ctx.lineTo(.010,.119);ctx.lineTo(-.001,.115);ctx.lineTo(.004,.125);ctx.closePath();ctx.fill();
  ctx.strokeStyle='#9c6d67';ctx.lineWidth=.00085;ctx.beginPath();ctx.moveTo(-.005,.115);ctx.lineTo(.002,.112);ctx.stroke();
  if(!enemy&&!girl){ctx.fillStyle='#584344';ctx.beginPath();ctx.arc(-.059,.155,.0018,0,Math.PI*2);ctx.fill();}
  if(s.strain>.2){
   ctx.strokeStyle='rgba(118,65,57,.5)';ctx.lineWidth=.0007;ctx.beginPath();
   ctx.moveTo(-.021,.216);ctx.lineTo(-.017,.227);ctx.moveTo(.018,.217);ctx.lineTo(.021,.229);ctx.stroke();
   // Tension at mouth corners, not a pasted unrelated expression.
   ctx.beginPath();ctx.moveTo(-.025,.079);ctx.lineTo(-.029,.070);ctx.moveTo(.025,.079);ctx.lineTo(.028,.071);ctx.stroke();
  }
  tex.needsUpdate=true;hair.userData.applyLag(s.hairYaw??0,s.hairPitch??0);
  for(const [j,part]of tips.entries()){
   const p=part.geo.attributes.position,uv=part.geo.attributes.uv;
   for(let i=0;i<p.count;i++){
    const w=THREE.MathUtils.smoothstep(uv.getY(i),.48,.96)**2;
    p.setXYZ(i,part.rest[i*3]+w*((s.hairYaw??0)*.06+Math.sin((s.windTime??0)*1.8+j)*.0015),part.rest[i*3+1],part.rest[i*3+2]+w*(s.hairPitch??0)*.06);
   }p.needsUpdate=true;
  }
 }};
}
class WindActor{
 constructor(kind){
  this.kind=kind;const enemy=kind==='jianwang',girl=kind==='weihe';
  this.mesh=new THREE.Group();this.mesh.name=kind;this.body=new THREE.Group();this.mesh.add(this.body);
  this.size=enemy?1.055:girl?.91:1;this.mesh.scale.setScalar(this.size);
  this.skin=skin(enemy?'#d9c6bf':girl?'#efd0b4':'#efc5a4');
  this.cloth=cloth(enemy?'#322b46':girl?'#647b77':'#203845');
  this.silver=new THREE.MeshStandardMaterial({color:enemy?'#594e67':'#95b9ca',metalness:.75,roughness:.32});
  this.body.position.y=.89;
  const torsoProfile=[[-.07,.109,.077],[0,.128,.088],[.10,.112,.077],[.20,.125,.089],[.32,.157,.105],[.395,.174,.108]];
  if(enemy||girl)torsoProfile.push([.46,.153,.080],[.49,.070,.051],[.55,.049,.044]);
  this.torsoGeo=ringsGeometry(dense(torsoProfile));
  mesh(this.body,this.torsoGeo,this.cloth,false);
  if(!enemy&&!girl)mesh(this.body,ringsGeometry(dense([[.395,.163,.104],[.445,.155,.083],[.49,.070,.051],[.55,.049,.044]])),this.skin,false);
  this.torsoRest=this.torsoGeo.attributes.position.array.slice();
  this.pelvis=ellipsoid(this.mesh,[0,.86,0],[.132,.13,.090],this.cloth,false);
  // The collar stays below the clavicles. The neck is visible in close views.
  mesh(this.body,ringsGeometry([[.46,.064,.052],[.51,.049,.044],[.58,.044,.042],[.65,.049,.043]]),this.skin,false);
  if(!enemy&&!girl)for(const s of [-1,1]){
   stroke(this.body,[[s*.012,.451,.060],[s*.065,.440,.072],[s*.123,.459,.065]],'#b7816d',.0018);
   stroke(this.body,[[s*.029,.55,.035],[s*.039,.505,.042],[s*.061,.468,.055]],'#cc9a80',.0012);
  }
  this.head=portrait(this.body,kind);this.head.root.position.y=.55;
  this.bones={head:this.head.root};
  this.arm={};this.leg={};this.hands={};this.feet={};this.shoulders={};this.sleeves={};this.bracers={};
  for(const [side,sgn]of[['left',-1],['right',1]]){
   this.arm[side]=new LimbSurface(this.mesh,enemy||girl?this.cloth:this.skin,[[0,.064],[.15,.063],[.32,.052],[.48,.039],[.59,.049],[.80,.035],[1,.025]],{depth:.89});
   this.leg[side]=new LimbSurface(this.mesh,this.cloth,[[0,.086],[.20,.081],[.48,.052],[.66,.062],[.86,.039],[1,.035]],{depth:.86});
   this.shoulders[side]=ellipsoid(this.mesh,[0,0,0],[.058,.066,.060],enemy||girl?this.cloth:this.skin,false);
   this.shoulders[side].visible=true;
   this.arm[side].mesh.children[0].visible=false;
   const hand=new ArticulatedHand(sgn,this.skin,jointInk);hand.scale.setScalar(.90);this.mesh.add(hand);this.hands[side]=hand;
   const foot=new THREE.Group();mesh(foot,shoeGeometry(),enemy?'#302638':girl?'#504b42':'#243b4b');foot.scale.set(.99,1,1.05);this.mesh.add(foot);this.feet[side]=foot;
   const bracer=new THREE.Group();mesh(bracer,new THREE.CylinderGeometry(.050,.040,.15,24),girl?this.cloth:this.silver,false);this.mesh.add(bracer);this.bracers[side]=bracer;
  }
  if(!girl){
   // Preserve the series' mature complete armour construction. The first
   // prototype's horizontal bands lost the established character silhouette.
   const base=enemy?new YekariCraft():new XiaozaoCraft();base.palaceKind=enemy?'jianwang':'xiaozao';
   applyPalaceCuirass(base,{integratedShoulders:false,signature:false});base.setCladState(1);
   const chestRoot=base.cladParts.find(p=>p.ord===1).groups[0];
   const top=enemy?1.588:1.388,start=enemy?1.39:1.19;
   chestRoot.traverse(m=>{
    if(!m.isMesh||m.parent?.name==='legacy-chest-plates')return;
    m.geometry=m.geometry.clone();const a=m.geometry.attributes.position;
    for(let i=0;i<a.count;i++){
     const y=a.getY(i);if(y>start)a.setY(i,y-.11*THREE.MathUtils.smoothstep(y,start,top));
    }a.needsUpdate=true;m.geometry.computeVertexNormals();
   });
   this.armour=base;this.mesh.add(base.mesh);base.body.removeFromParent();
   base.body.position.y=enemy?-.99:-.82;base.body.scale.set(enemy?1.30:1.24,1,1.35);this.body.add(base.body);
   base.headGroup.visible=false;base.torso.visible=false;
   for(const child of base.body.children)if(child.geometry?.type==='CylinderGeometry'&&Math.abs(child.geometry.parameters.height-.148)<.0001)child.visible=false;
   for(const side of ['left','right']){
    base.limbs[side+'Arm'].mesh.visible=false;base.limbs[side+'Leg'].mesh.visible=false;
    base.hands[side].visible=false;base.feet[side].visible=false;base.caps[side].visible=false;
   }
   if(base.cape)base.cape.group.visible=false;
   if(enemy)for(const child of base.body.children)if(child.geometry?.type==='TorusGeometry'&&child.position.y>1.5)child.visible=false;
   if(base.sickle)base.sickle.visible=false;
   base.chainLinks?.forEach(m=>m.visible=false);if(base.returnBlade)base.returnBlade.visible=false;
   this.shoulderArmour={};
   for(const side of ['left','right']){
    const cap=mesh(this.mesh,new THREE.SphereGeometry(1,32,20,0,Math.PI*2,0,Math.PI*.55),this.silver,false);
    cap.scale.set(.098,.052,.103);this.shoulderArmour[side]=cap;
   }
   // Skin appears at the upper-arm and neck transitions; armour owns torso form.
   this.pelvis.material=this.cloth;
  }
  this.disc=new THREE.Group();this.mesh.add(this.disc);
  this.discParts=[];
  for(let i=0;i<8;i++){
   const g=new THREE.Group(),a=i*Math.PI/4;
   const rim=mesh(g,new THREE.TorusGeometry(.145,.009,8,12,Math.PI/4-.025),this.silver,false);rim.rotation.z=a;
   const spoke=mesh(g,new THREE.BoxGeometry(.008,.12,.008),this.silver,false);spoke.position.set(Math.cos(a)*.08,Math.sin(a)*.08,0);spoke.rotation.z=a-Math.PI/2;
   this.disc.add(g);this.discParts.push(g);
  }
  this.disc.visible=!enemy&&!girl;this.last={};
 }
 pose(p){
  finitePose(p,this.kind);
  const hip=p.hip??.915;
  this.mesh.position.set(...(p.root??[0,0,0]));this.mesh.rotation.y=p.yaw??0;
  this.body.position.set(p.sway??0,hip,0);this.body.rotation.set(p.lean??0,p.twist??0,p.roll??0);
  this.pelvis.position.set(p.sway??0,hip-.025,0);this.pelvis.rotation.y=(p.twist??0)*.28;
  this.head.root.rotation.set(p.headPitch??0,p.headYaw??0,p.headRoll??0);
  this.body.updateMatrix();
  const transform=a=>V(a).applyMatrix4(this.body.matrix);
  const points={};
  for(const [side,sgn]of[['left',-1],['right',1]]){
   const shoulder=transform([sgn*.151,.427,0]);
   const wrist=V(p[side+'Hand']??[sgn*.24,hip+.01,.045]);
   const delta=wrist.clone().sub(shoulder),max=.295+.275-.002,reachError=Math.max(0,delta.length()-max);
   if(delta.length()>max)wrist.copy(shoulder).addScaledVector(delta.normalize(),max);
   const elbow=twoBone(obj(shoulder),obj(wrist),{x:sgn*.35,y:-.40,z:-.35},.295,.275);
   this.arm[side].update([obj(shoulder),elbow,obj(wrist)]);
   this.shoulders[side].position.copy(shoulder);
   const hand=this.hands[side];hand.position.copy(wrist);
   hand.quaternion.setFromUnitVectors(V([1,0,0]),wrist.clone().sub(V([elbow.x,elbow.y,elbow.z])).normalize());
   hand.rotateX(sgn*(p[side+'Palm']??.4));hand.setGesture({fist:p[side+'Fist']??.15,open:p[side+'Open']??0});
   const br=this.bracers[side],axis=wrist.clone().sub(V([elbow.x,elbow.y,elbow.z])).normalize();
   br.position.copy(wrist).addScaledVector(axis,-.085);br.quaternion.setFromUnitVectors(V([0,1,0]),axis);
   const ankle=V(p[side+'Foot']??[sgn*.11,.075,0]);
   const h=V([sgn*.090+(p.sway??0),hip-.02,0]),d=ankle.distanceTo(h);
   if(d>.8301)throw new Error(`${this.kind} leg unreachable ${d}`);
   const knee=twoBone(obj(h),obj(ankle),{x:sgn*.04,y:0,z:1},.425,.405);
   this.leg[side].update([obj(h),knee,obj(ankle)]);this.feet[side].position.copy(ankle);
   this.feet[side].rotation.set(p[side+'FootPitch']??0,p[side+'FootYaw']??0,0);
   points[side]={hip:h.toArray(),knee:[knee.x,knee.y,knee.z],foot:ankle.toArray(),shoulder:shoulder.toArray(),elbow:[elbow.x,elbow.y,elbow.z],hand:wrist.toArray(),reachError};
   if(this.armour){
    const a=this.armour;a.rigs[side].align(elbow,obj(wrist));a.shinRigs[side].align(knee,obj(ankle));
    a.kneeCaps[side].position.set(knee.x,knee.y,knee.z);
    this.shoulderArmour[side].position.copy(shoulder).add(V([0,.010,0]));
   }
  }
  const hp=points.left.hand;this.disc.position.set(...hp);this.disc.position.z+=.050;this.disc.rotation.set(.10,0,p.discRoll??0);
  this.discParts.forEach((m,i)=>m.visible=!(p.broken&&i<3));
  const arr=this.torsoGeo.attributes.position;
  for(let i=0;i<arr.count;i++){
   const x=this.torsoRest[i*3],y=this.torsoRest[i*3+1],z=this.torsoRest[i*3+2];
   const breath=(p.breath??0)*.004*Math.exp(-(((y-.34)/.13)**2));
   arr.setXYZ(i,x*(1+breath*1.2),y,z+Math.max(0,z/.11)*breath);
  }arr.needsUpdate=true;
  this.head.update(p.face??{});
  if(this.armour){
   for(const part of this.armour.cladParts)for(const g of part.groups)g.visible=part.ord!==0;
   for(const pd of this.armour.pauldronGroups)pd.g.visible=false;
   if(this.armour.sickle)this.armour.sickle.visible=false;
   if(this.armour.cape)this.armour.cape.group.visible=false;
   this.armour.updateCladFX(p.time??0,1);
  }
  this.mesh.updateMatrixWorld(true);
  for(const side of ['left','right'])points[side].footWorld=this.feet[side].getWorldPosition(new THREE.Vector3()).toArray();
  this.last={root:this.mesh.position.toArray(),yaw:this.mesh.rotation.y,hip,...points};
  return this.last;
 }
 anchor(side){return this.hands[side].getWorldPosition(new THREE.Vector3());}
}
export class XiaozaoWindCraft extends WindActor{constructor(){super('xiaozao');}}
export class JianwangCraft extends WindActor{constructor(){super('jianwang');}}
export class WeiheCraft extends WindActor{constructor(){super('weihe');}}
