import * as THREE from 'three';
import {SceneBase} from 'dula-engine';
import {continuousBackdrop} from '../../lib/craft3d/continuous-backdrop.js';
const V=a=>new THREE.Vector3(...a),clamp=x=>Math.max(0,Math.min(1,x));
const smooth=x=>{x=clamp(x);return x*x*(3-2*x);};
export class WindSievePalaceScene extends SceneBase{
 build(){
  this.scene.background=new THREE.Color('#596f7c');this.scene.fog=new THREE.FogExp2('#83989d',.022);
  this.scene.add(new THREE.HemisphereLight('#e2edf3','#394a57',2));
  const key=new THREE.DirectionalLight('#ffddbd',2.2);key.position.set(-5,8,7);this.scene.add(key);
  key.castShadow=true;key.shadow.mapSize.set(2048,2048);Object.assign(key.shadow.camera,{left:-8,right:8,top:8,bottom:-8,near:.1,far:30});key.shadow.bias=-.0005;
  const rim=new THREE.DirectionalLight('#a4dce5',1.8);rim.position.set(4,4,-5);this.scene.add(rim);
  this.stone=new THREE.MeshStandardMaterial({color:'#727d80',roughness:.94});
  this.wood=new THREE.MeshStandardMaterial({color:'#657073',roughness:.92});
  this.metal=new THREE.MeshPhongMaterial({color:'#aaa69a',shininess:36});
  const box=(w,h,d,x,y,z,m=this.stone,parent=this.scene)=>{
   const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;parent.add(o);return o;
  };
  this.bridge=new THREE.Group();this.scene.add(this.bridge);
  this.planks=[];
  for(let i=0;i<36;i++){
   const x=-6.3+i*.36,split=i===12||i===13;
   const p=box(.34,.13,split?1:2,x,-.065,split?.5:0,this.wood,this.bridge);this.planks.push(p);
   if(split)box(.34,.13,1,x,-.065,-.5,this.wood,this.bridge);
  }
  // Chasm has real side walls; the passage is a narrow bridge, not a room floor.
  for(const side of [-1,1]){
   box(6,1,9,side*8.8,-.5,0);
   for(let i=0;i<6;i++){
    const rock=new THREE.Mesh(new THREE.DodecahedronGeometry(1,1),this.stone);
    rock.position.set(side*(7+i*.6),-2-i*1.4,(i%3-1)*3);rock.scale.set(2.3,4,2.1);rock.castShadow=true;this.scene.add(rock);
   }
   for(const z of [-1.1,1.1]){
    for(const x of [-6,0,6]){
     box(.12,.95,.13,x,.43,z,this.metal);
     const cap=new THREE.Mesh(new THREE.SphereGeometry(.09,12,8),this.metal);cap.position.set(x,.95,z);this.scene.add(cap);
    }
   }
  }
  this.ropeLines=[];
  for(const z of [-1.1,1.1]){
   for(const y of [.54,.90]){
    const points=[];for(let i=0;i<=48;i++){const x=-6.4+i/48*12.8;points.push(V([x,y-.12*Math.sin(i/48*Math.PI),z]));}
    const o=new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points),64,.014,7,false),this.metal);o.userData.front=z>0;o.userData.rest=o.geometry.attributes.position.array.slice();this.scene.add(o);this.ropeLines.push(o);
   }
  }
  // Wind-filter sanctuary at the far end, with asymmetric broken screens.
  for(const x of [-8.0,8.0]){
   for(const z of [-2,2]){
    box(.55,4,.55,x,2,z);
    box(.85,.23,.85,x,4.05,z,this.metal);
   }
   box(.5,.35,5.3,x,4.25,0,this.metal);
   for(let i=0;i<9;i++)box(.11,3.4,.09,x,2.0,-1.6+i*.4,this.metal);
  }
  // Depth-separated silhouettes and light cloud veils.
  this.distantMountains=new THREE.Group();this.scene.add(this.distantMountains);
  for(let i=0;i<20;i++){
   const a=i/20*Math.PI*2,r=28+8*Math.sin(i*2.4),h=10+5*Math.sin(i*1.7);
   const m=new THREE.Mesh(new THREE.ConeGeometry(6,h,5),new THREE.MeshBasicMaterial({color:new THREE.Color('#516e7b').lerp(new THREE.Color('#9baeb1'),.3+.2*Math.sin(i))}));
   m.position.set(Math.cos(a)*r,-6,Math.sin(a)*r);m.rotation.y=i;this.distantMountains.add(m);
  }
  const cloudCanvas=document.createElement('canvas');cloudCanvas.width=256;cloudCanvas.height=128;const g=cloudCanvas.getContext('2d');
  const grad=g.createRadialGradient(128,64,5,128,64,126);grad.addColorStop(0,'rgba(230,239,234,.70)');grad.addColorStop(.6,'rgba(211,230,231,.24)');grad.addColorStop(1,'rgba(201,219,225,0)');
  g.fillStyle=grad;g.fillRect(0,0,256,128);const tex=new THREE.CanvasTexture(cloudCanvas);
  this.clouds=[];
  for(let i=0;i<14;i++){const m=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true,opacity:.48,depthWrite:false}));m.position.set((i%5-2)*12,-3-(i%3)*1.8,-6-Math.floor(i/5)*10);m.scale.set(30,9,1);m.userData.x=m.position.x;this.scene.add(m);this.clouds.push(m);}
  this.flags=[];
  for(const x of [-6,6])for(const z of [-2,2]){
   const flag=new THREE.Mesh(new THREE.PlaneGeometry(.55,1.8,6,18),new THREE.MeshStandardMaterial({color:'#98b3b4',side:THREE.DoubleSide,roughness:1}));
   flag.position.set(x,2.7,z);this.scene.add(flag);flag.userData.rest=flag.geometry.attributes.position.array.slice();this.flags.push(flag);
  }
  this.threads=new THREE.Group();this.scene.add(this.threads);this.threadParts=[];
  for(let i=0;i<7;i++){
   const geo=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(),new THREE.Vector3()]);
   const l=new THREE.Line(geo,new THREE.LineBasicMaterial({color:'#d0f2ed',transparent:true,opacity:.5}));this.threads.add(l);this.threadParts.push(l);
  }
  this.powder=new THREE.Points(new THREE.BufferGeometry(),new THREE.PointsMaterial({color:'#d8ffff',size:.025,transparent:true,opacity:.8,depthWrite:false}));
  const p=new Float32Array(180*3);this.powder.geometry.setAttribute('position',new THREE.BufferAttribute(p,3));this.scene.add(this.powder);
  this.box=new THREE.Group();box(.29,.24,.22,0,0,0,new THREE.MeshStandardMaterial({color:'#806d51'}),this.box);
  box(.31,.035,.24,0,.137,0,this.metal,this.box);box(.035,.26,.225,0,0,0,this.metal,this.box);this.scene.add(this.box);
  this.windTrails=[];
  for(let i=0;i<5;i++){
   const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(new Float32Array(20*3),3));
   const l=new THREE.Line(g,new THREE.LineBasicMaterial({color:'#def8f3',transparent:true,opacity:0,depthWrite:false}));this.scene.add(l);this.windTrails.push(l);
  }
  const cableGeo=new THREE.BufferGeometry();cableGeo.setAttribute('position',new THREE.BufferAttribute(new Float32Array(40*3),3));
  this.rescueCable=new THREE.Line(cableGeo,new THREE.LineBasicMaterial({color:'#c7c6a8'}));this.scene.add(this.rescueCable);
  this.fallingWood=new THREE.Mesh(new THREE.BoxGeometry(.25,.06,.60),this.wood);this.scene.add(this.fallingWood);
  this.foreshadowStone=new THREE.Mesh(new THREE.DodecahedronGeometry(.055,0),this.stone);this.scene.add(this.foreshadowStone);
  this.readyPromise=Promise.resolve();
 }
 async applyHybrid(base){
  const loader=new THREE.TextureLoader();
  const [sky,rock,stone]=await Promise.all(['backdrop_cloudpeak.png','peak_rock.png','palace_stone.png'].map(n=>loader.loadAsync(base+n)));
  for(const t of [sky,rock,stone]){t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=8;t.wrapS=t.wrapT=THREE.MirroredRepeatWrapping;}
  this.scene.add(continuousBackdrop(sky,{center:[0,5,0],cylinderRadius:70,cylinderHeight:38,repeat:2,offset:.1,zenith:'#75b2cc'}));
  this.distantMountains.visible=false;for(const c of this.clouds)c.visible=false;
  this.stone.map=rock;this.stone.color.set('#a9b2b3');this.stone.needsUpdate=true;
  this.wood.map=stone;this.wood.color.set('#9b9d95');this.wood.needsUpdate=true;
 }
 updateStory(t,s,actors){
  const tight=t>=17.4&&t<100.48;
  for(const [i,p]of this.planks.entries()){
   p.position.y=-.065+(tight?0:Math.sin(t*1.9+i*.23)*.012);
   const damaged=i===12||i===13;
   const fall=smooth((t-51.1)/1.5);
   p.rotation.z=damaged?-fall*.90:0;
   if(damaged)p.position.y-=fall*.85;
  }
  for(const rope of this.ropeLines){
   if(!rope.userData.front)continue;
   const pos=rope.geometry.attributes.position,r=rope.userData.rest,fall=smooth((t-51.1)/.8);
   for(let i=0;i<pos.count;i++){
    const x=r[i*3],drop=Math.exp(-(((x+1.72)/.60)**4))*fall;
    pos.setXYZ(i,x,r[i*3+1]-drop*.65,r[i*3+2]+drop*.08);
   }pos.needsUpdate=true;
  }
  this.fallingWood.visible=t>=51.1&&t<60;
  this.fallingWood.position.set(-1.72,-.2-Math.max(0,t-51.1)**1.65*.25,.4);
  this.fallingWood.rotation.set(t*.4,0,t*.7);
  this.foreshadowStone.visible=t>=11.4&&t<12.2;
  const block=smooth((t-11.4)/.5),disc=actors.xiaozao.anchor('left');
  this.foreshadowStone.position.copy(disc).add(V([.55*(1-block),.15*(1-block),.6*(1-block)]));
  for(const c of this.clouds)c.position.x=c.userData.x+Math.sin(t*.06)*2;
  for(const f of this.flags){
   const p=f.geometry.attributes.position,r=f.userData.rest;
   for(let i=0;i<p.count;i++){const x=r[i*3],y=r[i*3+1],w=(.9-y)/1.8;p.setZ(i,Math.sin(t*(tight?.5:2.3)+y*4+x*2)*.10*w+(tight?0:Math.sin(t*1.1+y*7)*.03*w));}
   p.needsUpdate=true;f.geometry.computeVertexNormals();
  }
  this.threads.visible=t>=17.4&&t<100.7;
  const a=actors.jianwang.anchor('right'),b=actors.xiaozao.anchor('left');
  for(let i=0;i<7;i++){
   const from=i<3?a.clone():V([i-5,.1,-1.08]),to=i<2?b:i===2?V([-1.72,.13,1.02]):V([i-4,.08,1.08]);
   from.y+=i<3?(i-1)*.025:0;
   const p=this.threadParts[i].geometry.attributes.position;p.setXYZ(0,...from.toArray());p.setXYZ(1,...to.toArray());p.needsUpdate=true;
   this.threadParts[i].material.opacity=t>=60.8?.72:t<28.9?.10:.34;
  }
  const dust=clamp((t-60.8)/.8)*(1-smooth((t-65)/2));
  this.powder.visible=dust>0;
  const pp=this.powder.geometry.attributes.position;
  for(let i=0;i<pp.count;i++){
   const u=(i*.61803398875)%1;const p=b.clone().lerp(a,u);
   p.y+=(Math.sin(i*2.4+t)*.16)*dust;p.z+=Math.sin(i*1.9)*.10;
   pp.setXYZ(i,...p.toArray());
  }pp.needsUpdate=true;this.powder.material.opacity=dust*.75;
  this.rescueCable.visible=t>=51.1&&t<99;
  const load=t>=78.8?actors.xiaozao.anchor('left'):actors.weihe.anchor('left');
  const curve=new THREE.CatmullRomCurve3([V([-3,.60,1.06]),load,V([-.20,.54,1.08])]);
  const cable=this.rescueCable.geometry.attributes.position;
  for(let i=0;i<cable.count;i++)cable.setXYZ(i,...curve.getPoint(i/(cable.count-1)).toArray());
  cable.needsUpdate=true;
  const w=actors.weihe.mesh;
  this.box.position.copy(w.localToWorld(V([0,1.05,.24])));this.box.rotation.y=w.rotation.y;
  const swing=s.swing??0,hand=actors.xiaozao.anchor(t>99?'left':'right');
  const forward=V([0,0,1]).applyQuaternion(actors.xiaozao.mesh.quaternion);
  for(const [j,l]of this.windTrails.entries()){
   const pos=l.geometry.attributes.position;l.visible=swing>0;l.material.opacity=swing*(.65-j*.07);
   for(let i=0;i<pos.count;i++){
    const u=i/(pos.count-1),p=hand.clone().addScaledVector(forward,(u-.8)*.55);
    p.y+=(j-2)*.022+Math.sin(Math.PI*u)*.05;
    p.x+=(j-2)*.012;pos.setXYZ(i,...p.toArray());
   }pos.needsUpdate=true;
  }
 }
}
