import * as THREE from 'three';
import {SceneBase} from 'dula-engine';
import {continuousBackdrop} from '../../lib/craft3d/continuous-backdrop.js';
const clamp=x=>Math.max(0,Math.min(1,x)),smooth=x=>{x=clamp(x);return x*x*(3-2*x);};
const V=a=>new THREE.Vector3(...a);

// An open gorge transfer station. No geometry or composition is inherited from
// the preceding fire palace: stone islands, diagonal wind screens and a cargo
// cable define this location's silhouette and its dramatic function.
export class WindSieveTerraceScene extends SceneBase{
 build(){
  this.scene.background=new THREE.Color('#9cb9c8');
  this.scene.fog=new THREE.Fog('#9cb4c0',15,55);
  this.scene.add(new THREE.HemisphereLight('#e1f0f4','#3e5963',1.35));
  const key=new THREE.DirectionalLight('#ffdfb9',1.8);key.position.set(-5,8,5);key.castShadow=true;
  key.shadow.mapSize.set(2048,2048);Object.assign(key.shadow.camera,{left:-9,right:9,top:10,bottom:-6,near:.1,far:40});key.shadow.bias=-.0004;
  this.scene.add(key);const rim=new THREE.DirectionalLight('#c1e9ff',1.15);rim.position.set(5,4,-6);this.scene.add(rim);
  this.stone=new THREE.MeshStandardMaterial({color:'#a8bbb9',roughness:.9});
  this.floor=new THREE.MeshStandardMaterial({color:'#9eaaa6',roughness:.83});
  this.dark=new THREE.MeshStandardMaterial({color:'#3b5963',roughness:.78});
  this.metal=new THREE.MeshStandardMaterial({color:'#77969d',metalness:.72,roughness:.38});
  const box=(w,h,d,x,y,z,m=this.stone,parent=this.scene)=>{
   const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;parent.add(o);return o;
  };
  const bar=(a,b,r,mat=this.metal,parent=this.scene)=>{
   a=V(a);b=V(b);const v=b.clone().sub(a),o=new THREE.Mesh(new THREE.CylinderGeometry(r,r,v.length(),10),mat);
   o.position.copy(a.clone().lerp(b,.5));o.quaternion.setFromUnitVectors(V([0,1,0]),v.normalize());o.castShadow=true;parent.add(o);return o;
  };
  // Stable tiled acting pad, supported by an eroded rock fin down into cloud.
  box(4.6,.35,3.1,0,-.2,.05,this.dark);
  for(let x=-3;x<=3;x++)for(let z=-2;z<=2;z++)box(.64,.08,.58,x*.65,-.04,z*.59,this.floor);
  for(let i=0;i<7;i++){
   const m=new THREE.Mesh(new THREE.DodecahedronGeometry(1,1),this.stone);
   m.position.set(Math.sin(i*2.1)*1.2,-2.55-i*1.4,Math.cos(i*2.1)*.55);
   m.scale.set(1.9-i*.16,2.3,1.25-i*.08);m.rotation.y=i*.7;m.castShadow=m.receiveShadow=true;this.scene.add(m);
  }
  // Three staggered rock shelves and narrow rear footbridge give parallax and
  // a real gap, rather than a floor ending against a sky painting.
  for(const sign of [-1,1]){
   const x=sign*4.2;box(2.8,.4,3.0,x,-.25,-2.5,this.floor);
   for(let j=0;j<3;j++){const m=new THREE.Mesh(new THREE.DodecahedronGeometry(1,1),this.stone);m.position.set(x+sign*j*.4,-3.35-j*2,-2.6);m.scale.set(2-j*.2,3,1.8);m.rotation.y=j+.4;this.scene.add(m);}
   box(.18,2.2,.24,sign*4.9,1.05,-2.5,this.metal);
   bar([sign*4.9,1.7,-2.5],[sign*3.5,.05,-3.5],.055);
  }
  for(let i=0;i<16;i++)box(.4,.10,.6,-3.4+i*.44,-.02,-3.75,this.floor);
  for(const z of [-4.1,-3.4])bar([-3.6,.53,z],[3.6,.53,z],.021);
  // Offset wind sieve: a fractured oval frame with curved ribs and cloth vanes.
  const screen=new THREE.Group();screen.position.set(.2,2.8,-6.0);screen.rotation.set(.02,-.16,-.19);screen.scale.set(1.25,1,1);
  this.scene.add(screen);this.vanes=[];
  for(const r of [2.65,2.42,1.65,.52]){
   const ring=new THREE.Mesh(new THREE.TorusGeometry(r,r>2?.10:.035,12,100,Math.PI*1.83),this.metal);ring.rotation.z=.16;ring.castShadow=true;screen.add(ring);
  }
  for(let i=0;i<16;i++){
   const a=i*Math.PI/8+.12;
   bar([Math.cos(a)*.53,Math.sin(a)*.53,0],[Math.cos(a)*2.43,Math.sin(a)*2.43,0],.023,this.metal,screen);
   if(i===1||i===12)continue;
   const shape=new THREE.PlaneGeometry(.39,1.40,5,14);
   const m=new THREE.Mesh(shape,new THREE.MeshStandardMaterial({color:i%3?'#7caaa9':'#d1c8a4',side:THREE.DoubleSide,roughness:.94}));
   m.position.set(Math.cos(a)*1.47,Math.sin(a)*1.47,.02);m.rotation.z=a-Math.PI/2;m.userData.rest=shape.attributes.position.array.slice();m.castShadow=true;screen.add(m);this.vanes.push(m);
  }
  // Asymmetric buttresses support the wind screen; no enclosing palace wall.
  for(const [x,h,z]of[[-3,3.7,-6.1],[3.2,4.6,-6.4]]){
   box(.62,h,.78,x,h*.5-1,z);
   for(let i=0;i<3;i++)box(.68,.13,.84,x,.25+i*.8,z,this.metal);
   const top=new THREE.Mesh(new THREE.ConeGeometry(.48,.66,4),this.metal);top.position.set(x,h-1+.3,z);top.rotation.y=Math.PI/4;this.scene.add(top);
  }
  // A visibly independent thick cargo cable and hand-carried medicine basket.
  bar([-4.9,1.7,-2.5],[4.9,1.7,-2.5],.024);
  this.medicine=new THREE.Group();this.medicine.name='medicine-cargo';this.scene.add(this.medicine);
  const wood=new THREE.MeshStandardMaterial({color:'#75553a',roughness:.88});
  const cream=new THREE.MeshStandardMaterial({color:'#d9ccb0',roughness:1});
  box(.62,.40,.44,0,0,0,wood,this.medicine);box(.66,.045,.48,0,.225,0,this.metal,this.medicine);
  for(const x of [-.24,.24]){box(.045,.42,.46,x,0,0,this.metal,this.medicine);bar([x,.24,-.16],[0,.95,0],.015,this.metal,this.medicine);}
  box(.28,.10,.50,0,.02,0,cream,this.medicine);
  const mark=new THREE.Mesh(new THREE.BoxGeometry(.09,.19,.012),new THREE.MeshStandardMaterial({color:'#7d3837'}));mark.position.set(0,.03,.238);this.medicine.add(mark);
  const mark2=mark.clone();mark2.scale.set(2.1,.45,1);this.medicine.add(mark2);
  for(const original of [mark,mark2]){const back=original.clone();back.position.z=-.256;this.medicine.add(back);}
  const wheel=new THREE.Mesh(new THREE.TorusGeometry(.077,.016,10,24),this.metal);wheel.position.set(0,.96,0);this.medicine.add(wheel);
  this.cargoEnd=V([3.35,.74,-2.5]);
  // Receiving cage partially hides the medicine after it arrives: the enemy's
  // former straight shot is closed by a real stone hood.
  box(.25,1.7,1.5,4.05,.65,-2.5);box(1.45,.2,1.5,3.45,1.45,-2.5);
  box(1.85,1.3,.20,3.45,.65,-1.78);
  this.dust=new THREE.Points(new THREE.BufferGeometry(),new THREE.PointsMaterial({color:'#ecf9f3',size:.018,transparent:true,opacity:.45,depthWrite:false}));
  this.dust.geometry.setAttribute('position',new THREE.BufferAttribute(new Float32Array(100*3),3));this.scene.add(this.dust);
  this.readyPromise=Promise.resolve();
 }
 async applyHybrid(base){
  this.readyPromise=(async()=>{
   const loader=new THREE.TextureLoader(),[sky,rock,stone]=await Promise.all(['backdrop_cloudpeak.png','peak_rock.png','palace_stone.png'].map(f=>loader.loadAsync(base+f)));
   sky.colorSpace=THREE.SRGBColorSpace;sky.wrapS=THREE.MirroredRepeatWrapping;
   for(const t of [rock,stone]){t.colorSpace=THREE.SRGBColorSpace;t.wrapS=t.wrapT=THREE.MirroredRepeatWrapping;t.anisotropy=8;}
   this.stone.map=rock;this.stone.bumpMap=rock;this.stone.bumpScale=.035;this.stone.needsUpdate=true;
   this.floor.map=stone;this.floor.bumpMap=stone;this.floor.bumpScale=.012;this.floor.needsUpdate=true;
   const backdrop=continuousBackdrop(sky,{center:[0,3,-3],cylinderRadius:55,cylinderHeight:33,radius:80,repeat:2,offset:.16,zenith:'#7eb7ce'});
   // This sky artwork ends in cloud. Fade the lower projection into haze rather
   // than stretching the final pixel row down the gorge.
   backdrop.material.fragmentShader=backdrop.material.fragmentShader.replace(
    '// A vertical ray', 'color=mix(vec3(.63,.73,.77),color,smoothstep(-.03,.12,v));\n// A vertical ray');
   this.scene.add(backdrop);
  })();return this.readyPromise;
 }
 updateStory(t,{cargo_safe}){
  const progress=smooth(t/Math.max(.1,cargo_safe));
  this.medicine.position.set(-3.35+6.70*progress,.74,-2.5);
  this.medicine.rotation.z=Math.sin(t*1.8)*.018*(1-smooth((t-cargo_safe)/.4));
  for(const [i,m]of this.vanes.entries()){
   const p=m.geometry.attributes.position,r=m.userData.rest;
   for(let j=0;j<p.count;j++)p.setZ(j,Math.sin(t*2.2+i*.8+r[j*3+1]*2.5)*.055*(.7-r[j*3+1])/1.4);
   p.needsUpdate=true;m.geometry.computeVertexNormals();
  }
  const p=this.dust.geometry.attributes.position;
  for(let i=0;i<p.count;i++)p.setXYZ(i,(i*.921+t*.35)%12-6,.3+(i*.387)%4,-5+(i*.567)%7);
  p.needsUpdate=true;this.dust.geometry.computeBoundingSphere();
 }
}
